#1810_pingan_hekashouxing_fe

### 安装依赖

cnpm i

### 调试

npm run dev

### 打包

npm run build

- dist文件夹即为项目打包目录

- 修改样式在css/index.less中

- 如果增加图片的话需要在script/handleIndex.js里引入 以免出现打包图片丢失的问题

- 模板html为 indexTmp.html  修改相关节点的话改这个文件即可