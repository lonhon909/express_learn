const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin')
const CleanWebpackPlugin = require('clean-webpack-plugin')
const ExtractTextWebpackPlugin = require('extract-text-webpack-plugin')
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const OptimizeCSSAssetsPlugin = require('optimize-css-assets-webpack-plugin');
//静态资源输出
const copyWebpackPlugin = require("copy-webpack-plugin");
module.exports = {
    mode:'production',
    entry: {
      index:"./scripts/handleIndex.js"
    },
    output: {
        path: path.join(__dirname, 'dist'),
        filename: 'js/[name].[hash].js',

    },
    module: {
      rules:[
        {
          test: /\.less$/,
          use:[
            MiniCssExtractPlugin.loader,
            'css-loader',
            'less-loader',
          ]
        },
        {
          test:/\.(jpg|png|gif|svg)$/,
          use:[
            {
              loader:'url-loader',
              options:{
                outputPath: 'images/',
                limit: 1,
                include:'./images/*',
                publicPath:'../images/',
                name: '[name].[ext]'
              }
            }
          ],
        }
      ]
    },
    plugins: [
      new HtmlWebpackPlugin({
        template: path.join(__dirname, './indexTmp.html'),
        inject: true,
        minify: {
          removeComments: true
        }
      }),
      new CleanWebpackPlugin(),
      new ExtractTextWebpackPlugin({
        filename: 'css/[name]-[hash].css' //放到dist/css/下
      }),
      new MiniCssExtractPlugin({
        filename: "css/[name]-[hash].css",
        chunkFilename: "css/[id]-[hash].css"
      }),
      new OptimizeCSSAssetsPlugin({
        assetNameRegExp: /\.css\.*(?!.*map)/g,  //需要根据自己打包出来的文件名来写正则匹配这个配置是我自己的
        cssProcessor: require('cssnano'),
        cssProcessorOptions: {
            discardComments: { removeAll: true },
            parser: require('postcss-safe-parser'),
            autoprefixer: false
        },
        canPrint: true
      }),
      new copyWebpackPlugin([{
        from: path.resolve(__dirname,"./scripts"),
        to: 'scripts/'
      }]),
      new copyWebpackPlugin([{
        from: path.resolve(__dirname,"./css/swiper.min.css"),
        to: 'css/'
      }]),
      new copyWebpackPlugin([{
        from: path.resolve(__dirname,"./music/brithday.mp3"),
        to: 'music/'
      }]),
      new copyWebpackPlugin([{
        from: path.resolve(__dirname,"./images/fireworks.json"),
        to: 'images/'
      }]),
      new copyWebpackPlugin([{
        from: path.resolve(__dirname,"./images/fireenter.json"),
        to: 'images/'
      }]),
    ],
    devServer: {
      contentBase: path.join(__dirname, "dist"), //静态文件根目录
      port: 9090, // 端口
      // host: 'localhost',
      host: '192.168.1.104',
      overlay: true,
      compress:true,
      hot:true
    }
}