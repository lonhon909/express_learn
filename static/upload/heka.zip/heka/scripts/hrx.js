/**
 * 集体开会整理
 * modified on 2018-03-27
 */

var ua = navigator.userAgent.toUpperCase();
var App = {};
// window.__hrxApp = App;
// window.App = App;

// 当前环境是否为Android平台
var isAndroid = App.isAndroid = ua.indexOf('ANDROID') != -1;
// 当前环境是否为IOS平台
var isIos = App.isIos = ua.indexOf('IPHONE OS') != -1;
var isHRX = App.isXRX = ua.indexOf('HRXAPP') !== -1;
// 判断是否运行在HRXAPP ios设备上
var _isHrxAppIos = ua.indexOf('HRXAPP-IOS') >= 0;
var callindex = 0;
var callbackIndex = 1;


/**
 * 调用一个Native方法
 * @param {String} name 方法名称
 */
function callApp(name) {
  // 获取传递给Native方法的参数
  var args = Array.prototype.slice.call(arguments, 1);
  var item = null;
  // 遍历参数
  for (var i = 0, len = args.length; i < len; i++) {
    item = args[i];
    if (item === "undefined") {
      item = '';
    }
    // 如果参数是一个Function类型, 则将Function存储到window对象, 并将函数名传递给Native
    if (typeof (item) == 'function') {
      var callbackName = '__hrx_' + name + '_callback_' + i + '_' + callbackIndex++;
      var functtt = item;
      window[callbackName] = item;
      item = callbackName;
    }
    args[i] = item;
  }

  if (window.zzapi) {
    callAppZZ(name, args);
  } else {
    if (_isHrxAppIos) {
      callAppKLPA(name, args);
    } else {
      console.log('无window.zzapi对象');
      //alert('无window.zzapi对象');
    }
  }
}



// 调用知知native
function callAppZZ(name, args) {
  var funcstr = '';
  try {
    for (var i = 0, len = args.length; i < len; i++) {
      if(typeof args[i] == 'string') {
        //防止popH5Window从详情返回到首页\n被转译
        //args[i] = args[i].replace(/[\\']/g,"\\'");
        args[i] = args[i].replace(/\'/g,"\\'");
      }
      args[i] = '\'' + args[i] + '\'';
    }
    funcstr = 'window.zzapi.' + name + '(' + args.join(',') + ')';
    console.log('H5调用Native函数: ' + funcstr);
    eval(funcstr);
  } catch (e) {
    console.log('H5调用Native函数异常: ' + funcstr);
    //alert('H5调用Native函数异常: ' + funcstr);
    console.log(e);
  }
}

// 调用HRX-APP ios(和快乐平安一致)
function callAppKLPA(name, args) {
  if (isAndroid) { // Android平台
    try {
      for (var i = 0, len = args.length; i < len; i++) {
        args[i] = '\'' + args[i] + '\'';
      }
      console.log(name + '' + JSON.stringify(args))
      eval('window.android.' + name + '(' + args.join(',') + ')');
      console.log('window.android.' + name + '(' + args.join(',') + ')');
    } catch (e) {
      console.log(e)
    }
  } else if (isIos) { // IOS平台
    if (args.length) {
      args = args.map(function(item) { // 将args里原本有的|替换成中文符号“｜”，防止影响到下面的|
        if (typeof item == 'string') {
          return item.replace(/\|/g, "｜");
        }else {
          return item;
        }
      })
      args = '|' + args.join('|');
    } else {
      args = '';
    }
    // IOS通过location.href调用Native方法, _call变量存储一个随机数确保每次调用时URL不一致
    callindex++;

    //版本兼容处理，v1.5.0以上使用iframe与ios交互，
    var version = App.getClientVersion();
    //给一个开关，当为true的时候表示是1.5.0以上版本
    var btn = false; 
    //获取版本号数组，如果是大于1.5.0版本就使用新版本
    var versionArr = version.split(".");
    //首先比较大版本号
    if(versionArr[0]>1){
      btn = true;
    }
    //比较中版本号
    if(versionArr[0]==1&&versionArr[1]>5){
      btn = true;
    }
    //最后比较小版本号
    if(versionArr[0]==1&&versionArr[1]==5&&versionArr[2]>0){
      btn = true;
    }
    if(btn){
      //使用新的iframe交互
      var url = 'hrx://__BRIDGE_LOADED__' + ('#ios:' + name + args + '|' + callindex);
      var WVJBIframe = document.createElement('iframe');
      WVJBIframe.style.width = '1px';
      WVJBIframe.style.height = '1px';
      WVJBIframe.style.display = 'none';
      WVJBIframe.src = url;
      document.body.appendChild(WVJBIframe);
      setTimeout(function() {
        document.body.removeChild(WVJBIframe)
      }, 1);
    }else{
      //继续使用旧的hash交互
      location.href = '#ios:' + name + args + '|' + callindex;
    }
  }
}

//1.改变title
App.changeTitle = function (titleName) {
  document.title = titleName;
  callApp("changeTitle", titleName);
};

//3.显示遮罩层
App.showLoading = function () {
  callApp("showLoading");
};
//4.隐藏遮罩层
App.hideLoading = function () {
  callApp("hideLoading");
};

//5.强制关闭遮罩层
App.loadFinish = function () {
  callApp("loadFinish");
};

//6.左上角返回回调，回调里定义返回的逻辑
App.back = function (callback) {
  window.back = callback;
};

//7.返回到navtive首页,native会调用window.back
App.backToHome = function () {
  callApp("backToHome");
};

//8.显示native提示框3秒后自动关闭
App.showWarnHUD = function (title) {
  callApp("showWarnHUD", title);
};

//9.显示native提示框用户点击确定关闭
App.showAlert = function (title) {
  console.info("enter App.showAlert.title:" + title);
  callApp("alert", title);
};

//10.获取AD账号 即是UM账号
//原名getAD
App.getUM = function (callbackFun) {
  callApp("getAD", callbackFun);
};

/*12.
 * 获取手机图片
 * @param {function} callback - h5回调
 * @param {object} option - 参数配置
 * @param {number} option.count - 可选图片张数，>1为多图选择，默认1即单图模式
 * @param {boolean} option.allowCrop - 是否允许裁剪, 只有单图模式才允许裁剪，默认不裁剪
 * @param {number} option.clipScale - 裁剪比例高/宽比h/w，当设置了允许裁剪，才需判断裁剪比例，默认值为1即正方形
 * @param {string} option.sourceType 'album'/'camera'/'both' - 可以指定来源是相册还是相机，默认二者都有
 * @param {number} option.minSize - 源图片最小尺寸，单位字节
 * @param {string} option.minSizeNote - 上传图片最小值超出限制，提示的错误信息，超出限制 返回示例 {code：-1，message：''}
 * @param {number} option.maxSize - 源图片最大尺寸，单位字节
 * @param {string} option.maxSizeNote - 上传图片最大值超出限制，提示的错误信息，超出限制 返回示例 {code：-1，message：''}
 * @param {string} option.sizeType 'original'/'compressed' - 可以指定是原图还是压缩图，默认为压缩图,如果为原图则忽略压缩尺寸
 * @param {array} option.compressRatio - 压缩后的尺寸大小，单位字节,对应图片原图片大小区间，0 - 512K ，512K-1M，1M-1.5M, 1.5M-2M ,2M-4M, 4M-6M , 6M-10M，10M 以上
 * 如果count>1, 忽略allowCrop,minSize,minSizeNote,maxSize,maxSizeNote,compressRatio
 * sourceType,sizeType可配置，固定比例压缩，忽略压缩比例
 * 单张图片例子
 * getPhoto(callback,{
 count:1,
 allowCrop: 'true',
 sourceType:'both',
 minSize:0.1*1024,
 minSizeNote:'图片质量过低',
 maxSize:10*1024*1024,
 maxSizeNote:'图片质量过高',
 sizeType:'compressed',
 compressRatio:[1,1,0.9,0.8,0.7,0.6,0.35,0.1]
 })
 * 多张图片例子
 * getPhoto(callback, {
 count:9,
 sourceType:'both',
 sizeType:'compressed',
 })
 *  正确返回示例： {
 *   code：1，
 *   data：[{
 *     base64data:’’,
 *     size:
 *     name:
 *   }]
 *  }
 *  错误返回示例
 *  { code: -1,
 *    message: '图片质量过高'
 *  }
 * */
App.getPhoto = function (callback,option) {
  callApp("getPhoto", function(params) {
    console.log('返回的字符串',params);
    var result = typeof params === 'string' ? JSON.parse(params) : params;
    callback(result);
  },JSON.stringify(option));
};

//13.talkingData信息采集 - 天眼
/**
 * @param {String} eventId 事件名称
 * @param {String} eventLabel 事件标签
 * @param {Object} parameters 事件参数
 */

App.sendTalkingData = function (eventId, eventLabel, parameters) {
  parameters = parameters || '{}';
  if(typeof parameters === 'object') {
    parameters = JSON.stringify(parameters);
  }
  callApp("sendTalkingData", eventId, eventLabel, parameters);
};

//14.GPS服务是否开启
App.locationServicesEnabled = function (callback) {
  callApp("locationServicesEnabled", callback);
};

//15.获取定位地址信息
App.getLocation = function (callback) {
  callApp("startLocation", function (res) {
    var json = JSON.parse(res);
    console.log('App.getLocation:', json);
    callback(json);
  });
};
// 手势验证
App.verifyPwd = function(callbackFuc, url) {
  console.info("verifyPwd");
  callApp("verifyPwd", callbackFuc, url);
}
/**
 * 18.调用native获取X-HRX-SESSION
 */
App.getSession = function (callbackFuc) {
  console.info("getSession");
  if (callbackFuc) {
    callApp("getSession", callbackFuc);
  }
};

/**
 * 20.ANDROID隐藏键盘
 */
//补充ios实现
App.hideKeyBoard = function () {
  callApp('hideKeyBoard');
};

// 24.跳转到本地包的路径
//目前无使用，需要测试
App.gotoLocalHref = function (url) {
  console.log('gotoLocalHref:' + url);
  callApp('gotoLocalHref', url);
}
// 25.跳转至第三方页面，native会默认控制返回
//目前无使用，需要测试
App.gotoAdHref = function (url) {
  console.log('gotoAdHref:' + url);
  callApp('gotoAdHref', url);
}
// 26.toast 消息
App.showWarnHUD = function (msg) {
  callApp("showWarnHUD", msg);
  console.log('showWarnHUD' + msg);
}
// 28.分享接口
/**
 * 分享接口
 * @param {Number} shareType 分享类型（目前只支持微信）
 * @param {*} linkURL 分享链接
 * @param {*} title 分享标题
 * @param {*} description 描述文字
 * @param {*} thumbUrl 缩略图 base64格式
 * @param {*} mediaTagName ''
 * @param {*} WXScene  0:分享到好友，1:分享到朋友圈
 * @param {*} callback
 */
//改造参数
App.shareGlobel = function (shareType, linkURL, title, description, thumbUrl, mediaTagName, WXScene, callback) {
  callApp("shareGlobel", shareType, linkURL, title, description, thumbUrl, mediaTagName, WXScene, callback);
};

function formatOptions(options) {
  options = options || {};
  options.pageId = options.pageId || '';
  options.navId = options.navId || '';
  options.backText = options.backText || '';
  options.titleText = options.titleText || '';
  options.searchText = options.searchText || '';
  return options;
}

/**32.
 * 打开H5页面
 * @param {string} url 如: /mobile/pamo/mobile/mysalary/gzd-chaxun.html?args=test
 * @param {number} withBackButton  0: 无; 1: 左下角有个圆形返回键;
 * @param {object} [options] h5传给native的配置参数
 * @param {object} [options.share] 是否可以分享，share里面4个参数：linkURL（分享链接），title（分享标题），description（分享描述），thumbUrl（分享图片）
 * @param {string} [options.animation] 转场动画 例如bottom-top
 * @param {string} [options.leftButtons] 左侧按钮，可以传两种参数：close（按钮为X），或者backAndClose（按钮为返回键和X都有），不传默认给返回键
 * @param {object} [options.param] 传到下一个页面的参数
 * @param {string} [options.pageId] 用来记录对应打开的webview的pageId可以用来做关闭历史记录，默认可以不传， - 1.3版本新增
 */
App.pushH5Window = function (url, withBackButton, options) {
  console.log('pushH5Window');
  options = formatOptions(options);
  callApp('pushH5Window', url, withBackButton, JSON.stringify(options));
}

/**34.
 * 关闭当前H5页面, 即返回到上一个页面
 * @param {string} animation - 转场动画 如top-bottom
 * @param {object} param - 传到上一个页面的参数
 */
App.popH5Window = function (animation, param) {
  console.log('popH5Window');
  callApp('popH5Window', animation, param);
}
// 2018-01-01开始新加功能, 没有经过严格测试
/**
 * 36.调用人脸识别
 * @param {number} isShowDialog 0：不显示弹窗直接开启摄像头识别人脸; 1: 显示弹窗不开启摄像头
 * @param {string} location     字符串为空不显示地址，有值显示地址
 * @param {number} backOption   0: 点击后退退到工作台，1：点击后退退到调用页面
 * @param {number} motionSwitch   0: 关闭动作开关，1：开启动作开关
 * @param {function} callback 回调函数
 */
App.openFaceRecognition = function (isShowDialog, location, backOption,motionSwitch, callback) {
  callApp('openFaceRecognition', isShowDialog, location, backOption,motionSwitch, function (msg) {
    callback(msg);
  });
}

/**
 * 37.获取客户端系统版本号
 */
App.getClientVersion = function (callback) {
  var hrxInfo = ua.substr(ua.indexOf('HRXAPP'));
  var hrxVerInfo = hrxInfo.split(' ')[0];
  var version = hrxVerInfo.split('/')[1].replace(/v/i, '');
  if (callback && typeof callback === 'function') {
    callback(version);
  } else {
    return version;
  }
};
//38.获取环境信息
App.getEnvironment = function (callback) {
  var hrxInfo = ua.substr(ua.indexOf('HRX-ENV'));
  var hrxVerInfo = hrxInfo.split(' ')[0];
  var env = hrxVerInfo.split('/')[1];
  if (callback && typeof callback === 'function') {
    callback(env);
  } else {
    return env;
  }
};
/**
 * 39.获取设备唯一ID
 * @param {function} callback 回调函数
 * @param {string} data 回调函数值 可能为空
 * @demo
 *  App.getDeviceId(function(data) {
 *      console.log(data);
 *  });
 */
App.getDeviceId = function (callback) {
  console.info("queryMoDeviceId");
  callApp('queryMoDeviceId', callback);
}

/**
 * 45.获取mac地址
 * @param {function} callback 回调函数
 * 返回值对象示例
 */
App.getMacAddress = function (callback) {
  console.log("getMacAddress");
  callApp('getMacAddress', function (msg) {
    callback(msg);
  });
};
/**
 * 46.打电话
 * @param {string} number
 */
App.callPhone = function (number) {
  callApp("CallPhone", number);
}
/**
 * 47.打开浏览器
 * @param {string} url
 */
App.openBrows = function (url) {
  callApp("OpenBrows", url);
}
/**
 * 48.拷贝文本
 * @param {string} text
 */
App.copyText = function (text) {
  callApp("CopyText", text);
}
/**
 * 49.添加联系人
 * @param {string} name
 * @param {string} number
 */
App.addContact = function (name, number) {
  callApp("AddContact", name, number);
}
/**
 * 50.返回登录首页
 * @param {string} name
 * @param {string} number
 */
App.backLoginView = function (callback) {
  callApp("backLoginView", function (msg) {
    callback(msg)
  });
}
// 失效登录 (只在IOS 实现)
App.invalidateToken = function () {
  callApp("invalidateToken");
}

function setWindowFun(item) {
  if (typeof (item) == 'function') {
    var callbackName = '__hrx_callback_selfset_' + callbackIndex++;
    window[callbackName] = item;
    return callbackName;
  }
}

function isArray(object) {
  return object && typeof object === 'object' &&
    typeof object.length === 'number' &&
    typeof object.splice === 'function' &&
    //判断length属性是否是可枚举的 对于数组 将得到false
    !(object.propertyIsEnumerable('length'));
}

/*
 * 51.切换native头部
 * @param {object} config, 如果此参数不传，则设置默认的头部
 * @param {string || object} config.title 头部标题，如果左侧是搜索框则不能设置标题，如果是object，包含text[文字内容]，icon[文字后面的icon地址包含本地hrx://协议以及外网]，callback[点击回调]
 * @param {object} config.left 左侧，左侧可以为图标、文字、搜索框，安卓要求，如果右侧为数组，左侧也要用数组结构
 * @param {object} config.right 右侧，右侧可以为图标、文字、下拉列表, 如果是多个类型，则用数组结构
 * @param {string} config.left.type/config.right.type 类型，可为icon、text，config.left.type可为search，config.right.type可为option，当type为"url"时候，表示icon会传入本地地址图片
 * @param {string} config.left.icon/config.right.icon 图标，如果type为icon, 必须设置此值, 可为内置的图标名称比如nav_close或者自定义图标的base64，当type为"url"的时候，icon会传入本地图片地址，如“hrx://html/modulename/xxxx.jpg"
 * @param {function} config.left.callback/config.right.callback 回调函数
 * @param {string} config.left.text/config.right.text 文本文字，如果type为text, 必须设置此值
 * @param {string} config.left.textColor/config.right.textColor 文本文字的颜色编码比如fff，如果type为text, 必须设置此值
 * @param {array} config.right.options 右侧下拉选项，如果config.right.type为option, 必须设置此值，元素为包含text和value的对象{text: 'a',value: 1,}
 * @param {string} config.left.placeholder 占位文字，如果左侧type为search，placeholder可以自定义，不设置则会用默认值
 * @param {number} config.shadow 头部是否需要阴影, 0:不需要，1:需要，不传默认有阴影
 * */
App.changeHeader = function (config) {
  if(config && config.title && (typeof config.title != "object")){
    document.title = config.title;
  }
  if (config) {
    if (config.left && isArray(config.left)) {
      config.left.forEach(function(item) {
        if (item.callback) {
          item.callback = setWindowFun(item.callback)
        }
        if (item.icon && item.icon.indexOf('data') == 0) {
          if (App.isIos) item.icon = encodeURIComponent(item.icon);
        }
      })
    } else {
      if (config.left && config.left.callback) {
        config.left.callback = setWindowFun(config.left.callback);
      }
      if (config.left && config.left.icon && config.left.icon.indexOf('data') == 0) {
        if (App.isIos) config.left.icon = encodeURIComponent(config.left.icon);
      }
    }

    //如果title是一个对象
    if(typeof config.title == "object"){
      if(config.title.text){
        document.title = config.title.text;
      }
      if (config.title && config.title.icon && config.title.icon.indexOf('data') == 0) {
        if (App.isIos) config.title.icon = encodeURIComponent(config.title.icon);
      }
      config.title.callback = setWindowFun(config.title.callback);
    }

    if (config.right && isArray(config.right)) {
      config.right.forEach(function(item) {
        if (item.callback) {
          item.callback = setWindowFun(item.callback)
        }
        if (item.icon && item.icon.indexOf('data') == 0) {
          if (App.isIos) item.icon = encodeURIComponent(item.icon);
        }
      })
    } else {
      if (config.right && config.right.callback) {
        config.right.callback = setWindowFun(config.right.callback);
      }
      if (config.right && config.right.icon && config.right.icon.indexOf('data') == 0) {
        if (App.isIos) config.right.icon = encodeURIComponent(config.right.icon);
      }
    }
    config = JSON.stringify(config);
  } else config = null;
  callApp('changeHeader', config);
}

/**
 * 头部搜索框聚焦
 * @param {function} callback
 */
App.searchFocus = function (callback) {
  callApp('focusCallback', callback);
}

/**
 * 头部搜索框失去焦点
 * @param {function} callback
 */
App.searchBlur = function (callback) {
  callApp('blurCallback', callback);
}

/**
 * 头部搜索框值改变
 * @param {function} callback
 */
App.valueChangeCallback = function(callback){
  callApp('valueChangeCallback', callback);
}

/*
 * 52.打开城市列表
 * @param {function} callback - 回调函数
 * */
//bbs私有api
App.openCitySelect = function (callback, param) {
  console.log('openCitySelect')
  callApp('openCitySelect', callback, param);
}

/*
 * 53.打开从右向左侧滑窗口
 * @param {string} url - 要跳转的页面地址
 * @param {string} param - 要传到第二个页面的参数
 * */
App.pushSlideWindow = function (url, param) {
  console.log('pushSlideWindow')
  callApp('pushSlideWindow', url, param);
}

/*
 * 54.关闭从右向左侧滑窗口
 * @param {string} param - 回传到第一个页面的参数
 * */
App.popSlideWindow = function (param) {
  console.log('popSlideWindow')
  callApp('popSlideWindow', param);
}

/*
 * 55.设置头部搜索框的文本
 * @param {string} param - 需要设置到搜索框的文本
 * */
App.setSearchKey = function (param) {
  console.log('setSearchKey')
  callApp('setSearchKey', param);
}

/*
 * 56.新的弱提醒接口，显示3s自动关闭
 * @param {string} title - 要显示的提示消息
 * 从上往下动画弱提示
 * */
App.showWeakMsg = function (title) {
  callApp("showWeakMsg", title);
};

/*
 * 57.关闭ios右滑返回
 * */
App.turnOffSlideBack = function () {
  if(App.isIos) {
    console.log('turnOffSlideBack')
    callApp('turnOffSlideBack');
  }
}

/*
 * 58.刷新招聘数据
 * */
App.refreshHrxInterviewData = function(){
  callApp("refreshHrxInterviewData",'1');
}

/*
 * 59.身份证OCR
 * */
App.openCardOCR = function (callback) {
    console.info("openCardOCR");
    callApp('openCardOCR', function (msg) {
        callback(msg);
    });
}
/**
 * 60.银行卡OCR
 * @param {function} callback 回调函数
 * 返回值对象示例 {success:true,cardNo='622538000000...',desc='调用成功'}
 */
App.openBankCardOCR = function (callback) {
    callApp('openBankCardOCR', function (res) {
        callback(res);
    });
}





/**
 * [61.设置状态栏颜色默认]
 * @param {[type]} type [默认0:黑色  1:白色]
 */
App.setStatusBar = function(type){
  callApp("statusBarType",type);
}

/**
 * [62.横屏操作]
 */
App.landSpace = function(callback){
  callApp("landSpace");
  callback && callback();
}

/**
 * 强制横屏
 */
App.forceLandSpace =function(){
  callApp("forceLandSpace");
}
/**
 * [63.竖屏操作]
 */
App.portrait = function(callback){
  callApp("portrait");
  callback && callback();
}

/**
 * [64.分享图片]
 * @param  {[type]} type   [分享类型 0：分享微信好友 1：朋友圈]
 * @param  {[type]} title   [分享标题]
 * @param  {[type]} content [分享内容]
 * @param  {[type]} url  [分享图片]
 */
App.sharePicture = function (type,title,content,url) {
  callApp("sharePicture", type,title, content, url);
}

/**
 * [65.设置状态栏颜色默认]
 * @param  {[type]} hexClor [16进制色值]
 * @param  {[type]} alpha   [透明度]
 */
App.setNavigationColor = function(hexClor,alpha){
  callApp("setNavigationColor",hexClor,alpha);
}

/**
 * [66.入职系统登录正式员工HRX]
 * @param  {Function} callback
 */
 App.jumpToRegularHRX = function(){
   callApp("jumpToRegularHRX");
 }

//////////BBS固有 - 废弃

// App.checkPosting = function (callback) {
//   return callback();
// }



 /**
  * [开始录音]
  * @param  {success: Function}
  * success回调方法返回参数res
  * res.success 用来处理录音过程中出现异常 res.success等于‘1’表示成功、‘0’表示失败。
  * res.msg 如果success为0表示失败时候，会有一个对应错误信息
  */
 App.startRecord = function(params){
   params.success = params.success || function(){};
   for(var i in params){
     if(params.hasOwnProperty(i) && (typeof params[i])==="function" ){
       var fn1 = params[i];
       var fn2 = function(res){
         if(typeof res == "string"){
           try{
             res = JSON.parse(res);
           }catch(e){
             console.log(e);
           }
         }
         fn1(res);
       }
       params[i] = setWindowFun(fn2);
     }
   }
   params = JSON.stringify(params);
   callApp("startRecord", params);
 }

 /**
  * [结束录音]
  * @param  {success: Function}
  * success回调方法返回参数res
  * res.success 用来处理录音过程中出现异常 res.success等于‘1’表示成功、‘0’表示失败。
  * res.localFile 音频数据base64，格式mp3或wav
  * res.msg 如果success为0表示失败时候，会有一个对应错误信息
  */
 App.stopRecord = function(params){
   params.success = params.success || function(){};
   for(var i in params){
     if(params.hasOwnProperty(i) && (typeof params[i])==="function" ){
       var fn1 = params[i];
       var fn2 = function(res){
         if(typeof res == "string"){
           try{
             res = JSON.parse(res);
           }catch(e){
             console.log(e);
           }
         }
         fn1(res);
       }
       params[i] = setWindowFun(fn2);
     }
   }
   params = JSON.stringify(params);
   callApp("stopRecord", params);
 }



 /**
  * [启动语音识别文字]
  * @param  {success: Function}
  * success回调方法返回参数res
  * res.success 用来处理录音过程中出现异常 res.success等于‘1’表示成功、‘0’表示失败。
  * res.text 语音识别出来文字
  * res.sessionIds 语言片段对应的sessionId数组 
  * res.msg 如果success为0表示失败时候，会有一个对应错误信息
  */
 App.startVoiceIdentify = function(callback){
   callback = callback || function(){};

   var fn1 = callback;
   var fn2 = function(res){
     if(typeof res == "string"){
       try{
         res = JSON.parse(res);
       }catch(e){
         console.log(e);
       }
     }
     fn1(res);
   }
   var fnName = setWindowFun(fn2);

   callApp("startVoiceIdentify", fnName);
 }


 /**
  * [开启强制侧滑手势]
  * @param
  */
  App.forceOpenSlideBack = function(){
    callApp("forceOpenSlideBack");
  }


  /**
   * [将手势到默认模式]
   * @param
   */
   App.slideBackToDefault = function(){
     callApp("slideBackToDefault");
   }


   /*获取用户信息
    * @param {function} callback - h5回调
    * @param {object} option - 返回参数
    * @param {number} option.employeeId - 员工ID
    * @param {number} option.umId - um账号
    * @param {number} option.token - sessionToken
    * @param {number} option.name - 用户姓名
    * @param {number} option.headerUrl - 获取用户头像地址
    * @param {number} option.environment - 环境
    * */
   App.getUser = function (callbackFun) {
     var fn1 = function(str){
       var params = (typeof str == "string")?(JSON.parse(str)):str;
       callbackFun(params)
     }
     callApp("getUser", fn1);
   };

  /**
    * [获取大标题顶部距离]
    * @param
    */
  App.largeTitleTop = function (callbackFun) {
    callApp("largeTitleTop", callbackFun);
  };


  /**
  * 跳转到native身边帖子编辑页面
  * @param {object} [options] h5传给native的参数
  */
  App.nativeEditbbs = function (options) {
    //options = formatOptions(options);
    options = options || {};
    callApp('nativeEditbbs', JSON.stringify(options));
  }

  /**调取手机放大功能
  * @param {object} params - 传入params对象
  * @param {array} params.images - 传入图片的地址
  params.images示例：
  params.images = ["https://xxx/xxxx/xxxxx/x.jpg"]
  * @param {number} params.index - 固定传入0 
  * @param {string} params.Base64 - 传入图片转base64后的字符串(static文件夹中已封装转换方法，名为imgToBase64)
  * @param {object} params.Img - 传入以图片左上角相对于整个屏幕的坐标及其宽高(X,Y,width,height) 
  params.Img对象示例：
  params.Img = {
    X:Element.getBoundingClientRect().left,
    Y:Element.getBoundingClientRect().top,
    width:Element.getBoundingClientRect().width,
    height:Element.getBoundingClientRect().height,
  }
  */
  App.nativePreviewImages = function (params) {
    params = params || {};
    callApp('nativePreviewImages', JSON.stringify(params));
  }



  /**调取手机图片长按保存功能
  * @param {string} params.img - 传入图片转base64后的字符串 
  */
  App.longPressImg = function (params) {
    params = params || {};
    callApp('longPressImg', JSON.stringify(params));
  }

  /**帖子预览侧滑回身边首页
  *
  * @param  {Object}
  */
  App.bbsPopWindowCallback = function(params){
    params = params || {};
    if(typeof params == "object"){
      params = JSON.stringify(params);
    }
    callApp("bbsPopWindowCallback", params);
  }


 /**
  * [调用评论弹框]
  * @param {string} postId - 帖子ID
  * @param {string} postTitle - 帖子标题
  * @param {string} createdBy - 帖子所有者UM账号
  * @param {string} pCommentId - 被回复内容ID
  * @param {string} commetUmId - 被回复者UM账号
  * @param {string} pName - 被回复者昵称
  * @param {string} picURL - 被回复者头像
  * @param {string} commentDetail - 被回复的内容
  * @param {function} success - 评论成功的回调
  */
App.nativeComment = function(params){
  params.success = params.success || function(){};
  for(var i in params){
   if(params.hasOwnProperty(i) && (typeof params[i])==="function" ){
     var fn1 = params[i];
     var fn2 = function(res){
       if(typeof res == "string"){
         try{
           res = JSON.parse(res);
         }catch(e){
           console.log(e);
         }
       }
       fn1(res);
     }
     params[i] = setWindowFun(fn2);
   }
  }
  params = JSON.stringify(params);
  callApp("nativeComment", params);
}

//判断是否有某个方法
/**
 * @param {String} name 要判断的方法名
 * @param {function} callback 回调，有的话返回1，没有返回0
 */
App.checkFn = function (name, callback) {
  if (App.isIos) {
    callApp("checkFn", function(status) {
      callback(status);
    }, name)
  }else { // 安卓直接通过 window.zzapi.方法名 判断
    var fn = 'window.zzapi.' + name;
    if (eval(fn)) {
      callback(1);
    }else {
      callback(0);
    }
  }
}


/**
 * [确认模态弹框] - 1.3版本新增
 * @param {object} params, 如果此参数不传，则所有参数都是用默认
 * @param {string} params.cancelText 取消按钮文字，默认是"取消"
 * @param {Boolean} params.mask 是否展示遮罩，默认是0，显示遮罩，1不显示，默认是0
 * @param {Boolean} params.maskClosable   点击蒙层是否允许关闭，默认是0点击蒙层关闭，如果传1标示点击蒙层不关闭
 * @param {string} params.okText 确认按钮文字，默认是"确认"
 * @param {string} params.title 标题
 * @param {string} params.titleAlign 标题对齐模式，默认0表示居中，居左为1，居右为2
 * @param {string} params.message 主体文字内容
 * @param {string} params.messageAlign 主体文字内容对齐模式，默认0表示居中，居左为1，居右为2
 * @param {Function} params.onCancel 点击遮罩层或取消按钮的回调
 * @param {string} params.needCancel 是否需要取消按钮，默认0需要，不需要为1，
 * @param {Function} params.onOk 点击确定回调
 */
App.confirm = function(params){
  params = params || {};
  params.onCancel = params.onCancel || function(){};
  params.onOk = params.onOk || function(){};
  for(var i in params){
    if(params.hasOwnProperty(i) && (typeof params[i])==="function" ){
      params[i] = setWindowFun(params[i]);
    }
  }
  params = JSON.stringify(params);
  callApp("confirm", params);
}


/*新版录音接口*/
/*开始录音startAuditionRecord (params)
/**
* @param  params.id  24个字符以内的唯一标识符
* @param  params.liveName 直播间名称 非必须
* @param  params.enableOffline 是否开启离线录音，默认不支持"0"，需要支持就传"1"
* @param  params.callback  回调处理异常/成功/其它指定情况
返回值对象示例 { success: true, msg: ‘xxxx’, voice:int } voice声纹大小
*/

App.startAuditionRecord = function(params){
  params = params || {};
  if(params.id==undefined){
    App.showAlert("必须带有唯一标识符id");
    return;
  }
  params.callback = params.callback || function(){};
  for(var i in params){
    if(params.hasOwnProperty(i) && (typeof params[i])==="function" ){
      params[i] = setWindowFun(params[i]);
    }
  }
  params = JSON.stringify(params);
  callApp("startAuditionRecord", params);
}

/*设置录音状态setStatusAuditionRecord (params)
/**
* @param  params.id  24个字符以内的唯一标识符
* @param  params.status 设置当前录音的状态值
* @param  params.callback  预留，暂时没有用到
*/

App.setStatusAuditionRecord = function(params){
  params = params || {};
  if(params.id==undefined){
    App.showAlert("必须带有唯一标识符id");
    return;
  }
  params.callback = params.callback || function(){};
  for(var i in params){
    if(params.hasOwnProperty(i) && (typeof params[i])==="function" ){
      params[i] = setWindowFun(params[i]);
    }
  }
  params = JSON.stringify(params);
  callApp("setStatusAuditionRecord", params);
}



/*结束录音stopAuditionRecord (params)
/**
* @param  params.id  24个字符以内的唯一标识符，必须
* @param  params.liveName 直播间名称 非必须
* @param  params.callback  结束之后，获取异常/成功后的URL
                 返回值对象示例 { success: true, url: 'xxxxxxxxx', msg: ‘xxxx’, time: ‘xxxxxxxxxx’ }
*/
App.stopAuditionRecord = function(params){
  params = params || {};
  if(params.id==undefined){
    App.showAlert("必须带有唯一标识符id");
    return;
  }
  params.callback = params.callback || function(){};
  for(var i in params){
    if(params.hasOwnProperty(i) && (typeof params[i])==="function" ){
      params[i] = setWindowFun(params[i]);
    }
  }
  params = JSON.stringify(params);
  callApp("stopAuditionRecord", params);
}


/*暂停录音pauseAuditionRecord (params)
/**
* @param  params.id  24个字符以内的唯一标识符
* @param  params.liveName 直播间名称 非必须
* @param  params.callback  回调处理异常/成功/其它指定情况
                 返回值对象示例 { success: true, url: 'xxxxxxxxx', msg: ‘xxxx’, time: ‘xxxxxxxxxx’ }，time只需在异常情况时返回
*/
App.pauseAuditionRecord = function(params){
  params = params || {};
  if(params.id==undefined){
    App.showAlert("必须带有唯一标识符id");
    return;
  }
  params.callback = params.callback || function(){};
  for(var i in params){
    if(params.hasOwnProperty(i) && (typeof params[i])==="function" ){
      params[i] = setWindowFun(params[i]);
    }
  }
  params = JSON.stringify(params);
  callApp("pauseAuditionRecord", params);
}


/*继续录音 reStartAuditionRecord (params)
/**
* @param  params.id  24个字符以内的唯一标识符
* @param  params.liveName 直播间名称 非必须
* @param  params.callback  回调处理异常/成功/其它指定情况
                  返回值对象示例 { success: true, msg: ‘xxxx’ }
*/
App.reStartAuditionRecord = function(params){
  params = params || {};
  if(params.id==undefined){
    App.showAlert("必须带有唯一标识符id");
    return;
  }
  params.callback = params.callback || function(){};
  for(var i in params){
    if(params.hasOwnProperty(i) && (typeof params[i])==="function" ){
      params[i] = setWindowFun(params[i]);
    }
  }
  params = JSON.stringify(params);
  callApp("reStartAuditionRecord", params);
}


//关闭指定页面 - 1.3版本新增
/**
 * @param {Array} pageIds 要关闭的页面id数组，pushH5Window注入的pageId
 * @param {function} callback 回调函数
 */
App.closePage = function(pageIds, callback){
  //以逗号分隔字符串，安卓那边接收不到数组
  pageIds = pageIds.join(",");
  callApp("closePage", pageIds, callback);
}


//获取当前网络状态 - 1.3版本新增
/**
 * @param {function} callback({networkStatus:0}) 回调函数，回调方法会把当前网络对应状态networkStatus返回回来
 * 无网络状态：0，wifi：1，移动网络:2
 */
App.getNetwork = function(callback){
  var fn1 = function(str){
    var params = (typeof str == "string")?(JSON.parse(str)):str;
    callback(params)
  }
  callApp("getNetwork", fn1);
}


/*统一处理params函数*/
function handleParams(params){
  params.onSuccess = params.onSuccess || function(){};
  params.onError = params.onError || function(error){console.log(error)};
  for(var i in params){
    if(params.hasOwnProperty(i) && typeof params[i] == "function"){
      (function(){
        //用一个自执行函数包装一下，防止var变量共享
        var fn1 = params[i];
        var fn2 = function(paramsCallback){
          try{
            paramsCallback = ((typeof paramsCallback == "string")?(JSON.parse(paramsCallback)):paramsCallback);
          }catch(e){
            console.log(e);
          }
          fn1(paramsCallback);
        }
        params[i] = setWindowFun(fn2)
      })();
    }
  }
  params = JSON.stringify(params);
  return params;
}

//后续所有新的接口都直接在这个数组里扩展
App.methods = [


  //禁止长时间不操作自动熄屏 - 1.4版本新增
  /* 执行后屏幕不会超出时间自动熄屏
   */
  "banExtinguishScreen",


  //恢复长时间不操作自动熄屏 - 1.4版本新增
  /** 执行后恢复长时间不操作自动熄屏
   */
  "regainExtinguishScreen",


  //开始播放空录音文件 - 1.4版本新增
  /** 防止锁屏后不能继续实时上传录音文件
   */
  "playBlankAudio",


  //停止播放空录音文件 - 1.4版本新增
  /** 停止播放空录音文件
   */
  "stopBlankAudio",


  /**
   * [文字转语音] - 1.4版本新增
   * @param {object} params, 如果此参数不传，则所有参数都是用默认
   * @param {string} params.text 需要转成语音的文字内容
   * @param {Boolean} params.callback(params={code:0, errorMsg, audioBase64:'xxxx'}) 转换成语音后的回调[函数包含返回状态码code:0表示异常，1表示成功，，如果异常则返回异常信息提示，如果成功会返回audioBase64]
   */
  "wordToAudio",

  //开启打卡日历提醒
  "openPunchCardRemind",


  //关闭打卡日历提醒
  "closePunchCardRemind",

  /**
   * 新版本调用人脸识别 - 1.4版本新增
   * @param {object} params 入参对象
   * @param {number} object.isShowDialog 0：不显示弹窗直接开启摄像头识别人脸; 1: 显示弹窗不开启摄像头
   * @param {string} object.location     字符串为空不显示地址，有值显示地址
   * @param {number} object.backOption   0: 点击后退退到工作台，1：点击后退退到调用页面
   * @param {function} object.onSuccess 成功回调函数
   * @param {function} object.onError 错误回调函数
   */
  "openFaceDetect",


  /**
   * 版本更新 - 1.4版本新增
   * @param {object} params 入参对象
   * @param {string} object.fromModule  1表示是招聘模块
   * @param {function} object.onSuccess 成功回调函数
   * @param {function} object.onError 错误回调函数
   */
  "updateVersion",

  /**
   * 清除缓存 - 1.4版本新增
   * @param {object} params 入参对象
   * @param {function} object.onSuccess 成功回调函数
   * @param {function} object.onError 错误回调函数
   */
  "clearCache",


  /**
   * 显示头部 - 1.4版本新增
   * @param {object} params 入参对象
   * @param {function} object.onSuccess 成功回调函数
   * @param {function} object.onError 错误回调函数
   */
  "showHeader",


  /**
   * 隐藏头部 - 1.4版本新增
   * @param {object} params 入参对象
   * @param {object} params.status-该参数只针对ios 隐藏头部后，webview是否顶到最顶部，包含状态栏区域，1:显示在状态栏下面【默认】，2:显示区域包含状态栏空间
   * @param {function} object.onSuccess 成功回调函数
   * @param {function} object.onError 错误回调函数
   */
  "hideHeader",


  /**
   * 打开外链帖子 - 1.4版本新增
   * @param {object} params 入参对象
   * @param {function} object.onSuccess 成功回调函数
   * @param {function} object.onError 错误回调函数
   * @param {string} object.postUrl 外链帖子链接
   * @param {number} object.seqId 外链帖子ID
   */
  "openViewpostsOutlink",


  /**
   * 清除iphone-x底部留白 - 1.4版本新增，只针对iphone-x
   * @param {object} params 入参对象
   * @param {function} object.onSuccess 成功回调函数
   * @param {function} object.onError 错误回调函数
   */
  "clearIphoneXBottomWhite",


  /**
   * 判断是否是最新版本 - 1.4版本新增，
   * @param {object} params 入参对象
   * @param {function} object.fromModule  1表示是招聘模块
   * @param {function} object.onSuccess 成功回调函数，返回参数{result: 0[表示不是最新版本], 1[表示是最新版本]}
   * @param {function} object.onError 错误回调函数
   */
  "decideNewestVersion",


  /**
   * 开启视频面试 - 1.4版本新增，
   * @param {object} params 入参对象
   * @param {string} params.name 文件名和房间名（目前暂时是一致，后面可能会有变动） 
   * @param {string} params.liveId 直播间ID
   * @param {string} params.resumeLink 面试中打开的候选人一表通链接
   * @param {string} params.evluateLink 完成面试，去评价跳转的链接
   * @param {string} params.source 候选人进入1，面试官2
   * @param {string} params.candidateId 候选人应聘ID，面试官进入无该参数
   * @param {string} params.audtionStartTime 面试开始时间，格式2018-08-30 10：30
   * @param {string} params.currentTime 系统当前时间，格式2018-08-30 10：30
   * @param {object} params.candidateInfo 候选人相关信息
   * @param {string} params.candidateInfo.name 候选人姓名
   * @param {string} params.candidateInfo.gender 候选人性别
   * @param {string} params.candidateInfo.headPic 候选人头像
   * @param {function} object.onSuccess 成功回调函数
   * @param {function} object.onError 错误回调函数
   */
  "videoInterview",



  /**
   * 跳转私信页面 - 1.5版本新增，
   * @param {object} params 入参对象
   * @param {string} object.umid 他人的umId
   * @param {function} object.onSuccess 成功回调函数，返回参数
   * @param {function} object.onError 错误回调函数
   */
  "chat",



  /**
   * 跳转第三方页面时候去控制横竖屏 - 1.5版本新增，
   * @param {object} params 入参对象
   * @param {string} params.url 要跳转的页面地址
   * @param {string} params.direction "0"表示竖屏【默认是竖屏】，"1"表示横屏，
   * @param {function} params.onSuccess 成功回调函数
   * @param {function} params.onError 错误回调函数
   */
  "gotoUrl",




  /**
   * 给应用打分 - 1.5版本新增，
   * @param {object} params 入参对象
   * @param {string} params.type "1"表示弹出评分弹出框，"2"表示直接去应用市场
   * @param {string} params.title 弹出框主标题，
   * @param {string} params.subTitle 弹出框副标题，
   * @param {string} params.btnText 弹出框跳转按钮文字内容，
   * @param {function} params.onSuccess 成功回调函数
   * @param {function} params.onError 错误回调函数
   */
  "giveScore",


  /**
   * 刷新HRX首页接口 - 1.5版本新增，
   * @param {object} params 入参对象
   * @param {function} params.onSuccess 成功回调函数
   * @param {function} params.onError 错误回调函数
   */
  "refreshHrxHome",


  /**
   * word, excel, pdf预览 - 1.5版本新增，
   * @param {object} params 入参对象
   * @param {array} params.urls 需要预览的word, excel, pdf地址的数组，数组暂时只支持传入一个地址
   * @param {array} params.title 显示在预览头部的标题，如果不传就使用文件名，不包含后面的后缀
   * @param {function} params.onSuccess 成功回调函数，暂留，可以不传，暂时没有什么实际意义
   * @param {function} params.onError 错误回调函数，暂留，可以不传，暂时没有什么实际意义
   */
  "previewWordExcelPdf",





  /**
   * 用于鉴权 - 1.5版本新增，
   * @param {object} params 入参对象  具体对象入参暂时预留
   * @param {string} params.corpId 企业id
   * @param {string} params.appId 应用id
   * @param {string} params.timestamp 生成签名的时间戳
   * @param {string} params.nonceStr 生成签名的随机串
   * @param {string} params.signature 签名信息
   * @param {array} params.jsApiList 需要使用的jsapi列表
   */
  "config",



  /**
   * [启动语音识别文字]
   * @param  {onSuccess: Function}
   * param.onSuccess回调方法返回参数res
   * res.success 用来处理录音过程中出现异常 res.success等于‘1’表示成功、‘0’表示失败。
   * res.text 语音识别出来文字
   * res.audioUrl 返回本地的当前语音的url地址
   * res.sessionIds 语言片段对应的sessionId数组 
   * res.msg 如果success为0表示失败时候，会有一个对应错误信息
   */
  "startVoiceDiscern",



  /**
   * 生成授权码 - 1.5版本新增，
   * @param {object} params 入参对象
   * @param {string} params.appId 企业id
   */
  "getAuthCode",



  /*获取手机图片 - 1.5.0版本新增
   * @params
   * @params {object} params - 参数配置
   * @params {object} params.onSuccess - 成功回调
   * @params {object} params.onSelectDone - 完成选择后触发
   * @params {number} params.count - 可选图片张数，>1为多图选择，默认1即单图模式
   * @params {boolean} params.allowCrop - 是否允许裁剪, 只有单图模式才允许裁剪，默认不裁剪
   * @params {number} params.clipScale - 裁剪比例高/宽比h/w，当设置了允许裁剪，才需判断裁剪比例，默认值为1即正方形
   * @params {string} params.sourceType 'album'/'camera'/'both' - 可以指定来源是相册还是相机，默认二者都有
   * @params {number} params.minSize - 源图片最小尺寸，单位字节
   * @params {string} params.minSizeNote - 上传图片最小值超出限制，提示的错误信息，超出限制 返回示例 {code：-1，message：''}
   * @params {number} params.maxSize - 源图片最大尺寸，单位字节
   * @params {string} params.maxSizeNote - 上传图片最大值超出限制，提示的错误信息，超出限制 返回示例 {code：-1，message：''}
   * @params {string} params.sizeType 'original'/'compressed' - 可以指定是原图还是压缩图，默认为压缩图,如果为原图则忽略压缩尺寸
   * @params {array} params.compressRatio - 压缩后的尺寸大小，单位字节,对应图片原图片大小区间，0 - 512K ，512K-1M，1M-1.5M, 1.5M-2M ,2M-4M, 4M-6M , 6M-10M，10M 以上
   * 如果count>1, 忽略allowCrop,minSize,minSizeNote,maxSize,maxSizeNote,compressRatio
   * sourceType,sizeType可配置，固定比例压缩，忽略压缩比例
   * 单张图片例子
   * getPic({
   onSuccess: function(res){},
   onSelectDone: function(){},
   count:1,
   allowCrop: 'true',
   sourceType:'both',
   minSize:0.1*1024,
   minSizeNote:'图片质量过低',
   maxSize:10*1024*1024,
   maxSizeNote:'图片质量过高',
   sizeType:'compressed',
   compressRatio:[1,1,0.9,0.8,0.7,0.6,0.35,0.1]
   })
   * 多张图片例子
   * getPic({
   onSuccess: function(res){},
   onSelectDone: function(){},
   count:9,
   sourceType:'both',
   sizeType:'compressed',
   })
   *  正确返回示例： {
   *   code：1，
   *   data：[{
   *     base64data:’’,
   *     size:
   *     name:
   *   }]
   *  }
   *  错误返回示例
   *  { code: -1,
   *    message: '图片质量过高'
   *  }
   * */
  "getPic",


  /**
   * 回到候选人首页 - 1.5.0版本新增，
   * @param {object} params 入参对象
   */
  "backToCandidateHome",


  /*获取手机图片返回图片url - 1.6.0版本新增
   * @params
   * @params {object} params - 参数配置
   * @params {function} params.onSuccess - 全部上传成功回调，返回数组[{innerUrl, key, isFromNormalHeader, outerUrl}, {innerUrl, key, isFromNormalHeader, outerUrl}, {innerUrl, key, isFromNormalHeader, outerUrl}]，innerUrl内网地址,outerUrl外网地址, key是上传iobs后返回对应的key值， isFromNormalHeader如果是"0"表示是从选择默认头像中获取的，如果是"1"表示是从相册或者拍照获取
   * @params {function} params.onSelectDone - 完成选择后触发，返回参数{num:9}表示选择了9张图片
   * @params {function} params.onGetPicDetails - 获取选择图片详情，包括名字和大小，大小单位是字节，[{title, size}, {title, size}]
   * @params {function} params.onGetSmallDone - 完成获取缩略图数组，返回[base64, base64]，表示返回选中图片的缩略图片base64
   * @params {function} params.onPicUploaded - 每上传成功一张触发一次，返回{index, innerUrl, key, outerUrl},index表示上传成功图片下坐标，从0开始，innerUrl内网地址,outerUrl外网地址，key是上传iobs后返回对应的key值，
   * @params {function} params.onPicUploadError - 每上传失败一张触发一次，返回{index, msg},index表示上传成功图片下坐标，从0开始，msg表示上传失败原因
   * @params {function} params.onError - 调用native接口出错，直接导致不会去上传，返回{msg:"xxx"}表示返回出错原因
   * @params {function} params.onComplate - 全部结束后触发，不管是不是全部上传成功，还是其中有失败，返回数组[{innerUrl, key, isFromNormalHeader, outerUrl}, null, {innerUrl, key, isFromNormalHeader, outerUrl}]，null表示上传失败图片, isFromNormalHeader如果是"0"表示是从选择默认头像中获取的，如果是"1"表示是从相册或者拍照获取，key是上传iobs后返回对应的key值，
   * @params {string} params.needChangeHeader - 是否带头像切换功能，默认是"0"表示不需要，当传入"1"表示需要
   * @params {string} params.gender - 头像性别，默认是"0"表示男性，当传入"1"表示是女性头像
   * @params {number} params.count - 可选图片张数，>1为多图选择，默认1即单图模式
   * @params {boolean} params.allowCrop - 是否允许裁剪, 只有单图模式才允许裁剪，默认不裁剪
   * @params {number} params.clipScale - 裁剪比例高/宽比h/w，当设置了允许裁剪，才需判断裁剪比例，默认值为1即正方形
   * @params {string} params.sourceType 'album'/'camera'/'both' - 可以指定来源是相册还是相机，默认二者都有
   * @params {number} params.minSize - 源图片最小尺寸，单位字节
   * @params {string} params.minSizeNote - 上传图片最小值超出限制，提示的错误信息，超出限制 返回示例 {code：-1，message：''}
   * @params {number} params.maxSize - 源图片最大尺寸，单位字节
   * @params {string} params.maxSizeNote - 上传图片最大值超出限制，提示的错误信息，超出限制 返回示例 {code：-1，message：''}
   * @params {string} params.sizeType 'original'/'compressed' - 可以指定是原图还是压缩图，默认为压缩图,如果为原图则忽略压缩尺寸
   * @params {array} params.compressRatio - 压缩后的尺寸大小，单位字节,对应图片原图片大小区间，0 - 512K ，512K-1M，1M-1.5M, 1.5M-2M ,2M-4M, 4M-6M , 6M-10M，10M 以上
   * 如果count>1, 忽略allowCrop,minSize,minSizeNote,maxSize,maxSizeNote,compressRatio
   * sourceType,sizeType可配置，固定比例压缩，忽略压缩比例
   * 单张图片例子
   * getPhotoForUrl({
   onSuccess: function(res){},
   onSelectDone: function(){},
   count:1,
   allowCrop: 'true',
   sourceType:'both',
   minSize:0.1*1024,
   minSizeNote:'图片质量过低',
   maxSize:10*1024*1024,
   maxSizeNote:'图片质量过高',
   sizeType:'compressed',
   compressRatio:[1,1,0.9,0.8,0.7,0.6,0.35,0.1]
   })
   * 多张图片例子
   * getPhotoForUrl({
   onSuccess: function(res){},
   onSelectDone: function(){},
   count:9,
   sourceType:'both',
   sizeType:'compressed',
   })
   * */
  "getPhotoForUrl",




  /**
   * 获取未读消息 - 1.6.0版本新增，
   * @param {object} params 入参对象
   * @param {string} params.type - 获取未读消息类型type: "0"，表示候选人
   * @param {function} params.onSuccess - 成功回调函数，返回jsonObject，{num: 2}表示未读数量，如果数量为0就是{num: 0}
   * @param {function} params.onError - 获取失败
   */
  "getUnreadMessage",


  /**
   * 去到候选人消息列表 - 1.6.0版本新增，
   * @param {object} params 入参对象
   * @param {function} params.onSuccess
   * @param {function} params.onError
   */
  "goToCandidateMessage",


  /**
   * 关闭一表通界面 - 1.6.0版本新增，
   * @param {object} params 入参对象
   * @param {function} params.onSuccess
   * @param {function} params.onError
   */
  "closeResume",



  /**
   * 开始语音识别 - 1.6.0版本新增，
   * @param {object} params 入参对象
   * @param {function} params.onSuccess 正式开始启动触发
   * @param {function} params.onError({code:1}) 语音识别异常情况 1:来电，2:关来电，3:切后台，4:切前台，5:锁屏，6:解锁，7:断网，8:恢复网络，9:麦克风未授权
   * @param {function} params.onGetVolume({volume:21}) 即时返回当前音量值，number类型，数值范围0-100
   * @param {function} params.onGetText({text:"你好"}) 即时语音识别出来的文字，string类型
   */
  "startVoiceToWord",

  /**
   * 暂停语音识别 - 1.6.0版本新增，
   * @param {object} params 入参对象
   * @param {function} params.onSuccess
   * @param {function} params.onError
   */
  "pauseVoiceToWord",


  /**
   * 重新开始语音识别 - 1.6.0版本新增，
   * @param {object} params 入参对象
   * @param {function} params.onSuccess
   * @param {function} params.onError
   */
  "restartVoiceToWord",

  /**
   * 结束语音识别 - 1.6.0版本新增，
   * @param {object} params 入参对象
   * param.onSuccess回调方法返回参数res
   * res.success 用来处理录音过程中出现异常 res.success等于‘1’表示成功、‘0’表示失败。
   * res.text 语音识别出来文字
   * res.audioUrl 返回本地的当前语音的url地址
   * res.totalTime 返回本地的当前语音的总时长，number类型，单位是秒
   * res.sessionIds 语言片段对应的sessionId数组 
   * res.msg 如果success为0表示失败时候，会有一个对应错误信息
   * @param {function} params.onError
   */
  "stopVoiceToWord",


  /**
   * 启用/禁止截屏警告 - 1.6.0版本新增，
   * @param {object} params 入参对象
   * @param.flag {number} 如果不传默认0表示恢复默认允许截屏且不提示警告， 传入1表示启用截屏后提示截屏警告，传入2表示彻底禁止截屏
   * @param.onSuccess {function} 启动成功回调
   * @param.onError {function} 启动失败回调
   */
  "enableScreenshot",


  /**
   * 启用/禁止水印 - 1.6.0版本新增，
   * @param {object} params 入参对象
   * @param.flag {number} 如果不传默认0表示启用水印， 传入1表示禁止水印
   * @param.onSuccess {function} 启动成功回调
   * @param.onError {function} 启动失败回调
   */
  "enableWatermark",



  /**
   * 获取头像地址 - 1.6.0版本新增，
   * @param {object} params 入参对象
   * @param.onSuccess {function(res)} 成功回调，返回参数{headerUrl: "xxxx"} - 返回头像地址headerUrl
   * @param.onError {function(res)} 失败回调 {"msg": "获取失败原因"} 如果返回字段msg就表示失败
   */
  "getHeaderUrl",


  /**
   * 保存头像地址 - 1.6.0版本新增，
   * @param {object} params 入参对象
   * @param.iobsStr {string} 'choosePhotoStr'表示是从默认头像选择，可以不传，表示是从图库或者拍照
   * @param.imageId {string} iobs返回的key
   * @param.iobsKey {string} 使用上传图片返回的外网地址
   * @param.onSuccess {function(res)} 成功回调，返回参数{"msg": "获取失败原因"} - 如果返回字段msg就表示失败
   * @param.onError {function} 失败回调 {"msg": "获取失败原因"}
   */
  "saveHeaderUrl"



  



];


//兼容低版本使用for循环，以及防止变量污染使用一个自执行函数
(function(){
  for(var i=0, len=App.methods.length; i<len; i++){
    //使用闭包防止i被变换
    App[App.methods[i]] = (function(j){
      return function(params){
        params = params || {};
        params = handleParams(params);
        callApp(App.methods[j], params);
      }
    }(i));
  }
})();



//用来处理鉴权成功回调
App.readyFns = [];
App.ready = function(fn){
  //如果当前readyFns已经有数据了表示已经绑定过函数了，就不用再绑定了，只有等于0才去执行绑定
  if(App.readyFns.length==0){
    (function(){
      //申明一个函数用来执行readyFns存储的回调
      var fnAll = function(){
        for(var i=0, len=App.readyFns.length; i<len; i++){
          App.readyFns[i]();
        }
        //执行完后清空readyFns数组
        App.readyFns = [];
      }
      var fnAllString = setWindowFun(fnAll);
      App.readyFns.push(fn);
      callApp("ready", fnAllString);
    }())
  }else{
    App.readyFns.push(fn);
  }

};


//用来处理鉴权失败回调
App.errorFns = [];
App.error = function(fn){
  //如果当前errorFns已经有数据了表示已经绑定过函数了，就不用再绑定了，只有等于0才去执行绑定
  if(App.errorFns.length==0){
    (function(){
      //申明一个函数用来执行errorFns存储的回调
      var fnAll = function(){
        for(var i=0, len=App.errorFns.length; i<len; i++){
          App.errorFns[i]();
        }
        //执行完后清空readyFns数组
        App.errorFns = [];
      }
      var fnAllString = setWindowFun(fnAll);
      App.errorFns.push(fn);
      callApp("error", fnAllString);
    }())
  }else{
    App.errorFns.push(fn);
  }
};





// native回调h5都在此代码块内处理
;
(function () {
  var nativeCallback = {};
  /**
   * @param {string} functionName
   * @param {string} param 参数
   */
  window.zzcallback = function (functionName, param) {
    console.log('window.zzcallback');
    if (!nativeCallback[functionName]) {
      console.log('H5没侦听native回调<' + functionName + '>')
      console.log(nativeCallback);
      return;
    }
    try {
      console.log('start ------------ nativeCallback');
      nativeCallback[functionName](param);
      console.log('end ------------ nativeCallback');
    } catch (error) {
      console.error('native回调JS"' + functionName + '"出错:' + error);
      console.error(error);
    }
  }

  /**
   * @param {string} functionName 回调函数名
   * @param {string} callback H5业务代码注册的回调函数
   */
  function registNativeCallback(functionName, callback) {
    if (callback) {
      nativeCallback[functionName] = callback;
    } else {
      delete nativeCallback[functionName];
    }
  }

  // 返回回调, 特殊处理
  registNativeCallback('back', function (param) {
    console.log('registNativeCallback("back"');
    if(typeof window.back === 'function'){
      window.back();
    }
  });

  /**
   * @callback zzcbRefreshByBack
   * @param {josn-string} param 上一个页面传递过来的参数
   */
  /**
   * A页面打开B页面，B页面关闭后, native会调用A页面的此函数，
   * 并将B页面App.zzcbBack函数的返回值作为参数传给此函数
   * @param {zzcbRefreshByBack} callback H5业务代码注册的回调函数
   */
  App.zzcbRefreshByBack = function (callback) {
    registNativeCallback('refreshByBack', callback);
  }



  /**
   * 关闭打开第三方页面触发回调，pushH5Window(...,..,{leftButtons: 'backAndClose',}) - 1.5.0版本新增，
   * @param {function} 关闭打开第三方页面触发回调函数
   */
  App.callbackByClosePage = function (callback) {
    registNativeCallback('callbackByClosePage', callback);
  }


  /**
   * 当前界面是否可见
   */
  App.pageVisibility = function(callback){
    registNativeCallback("pageVisibility",callback);
  }


  /**
   * 绑定点击头部触发事件
   */
  App.scrollToTop = function(callback){
    registNativeCallback("scrollToTop",callback);
  }




  /**
   * 显示键盘后触发回调事件， - 1.3版本新增
   * callback传递键盘高度参数回来
   */
  App.showKeyBoardCallback = function(callback){
    registNativeCallback("showKeyBoardCallback",callback);
  }

  /**
   * 隐藏键盘后触发回调事件， - 1.3版本新增
   * callback传递键盘高度参数回来
   */
  App.hideKeyBoardCallback = function(callback){
    registNativeCallback("hideKeyBoardCallback",callback);
  }


  /**
   * 注册网络切换触发回调 - 1.3版本新增
   * callback传递切换后的网络状态以及切换前网络状态，callback({newNetworkStatus:0, oldNetworkStatus:0}), 
   * 无网络状态：0，wifi：1，移动网络:2
   */
  App.networkChanged = function(callback){
    var fn1 = function(str){
      var params = (typeof str == "string")?(JSON.parse(str)):str;
      callback(params)
    }
    registNativeCallback("networkChanged", fn1);
  }


  /**
   * 注册系统异常情况 - 1.3.1版本新增
   * callback传递发现异常情况的状态码，callback({code:1}), 
   * 1:来电，2:关来电，3：切后台，4：切前台，5：锁屏，6解锁
   */
  App.systemAbnormal = function(callback){
    var fn1 = function(str){
      var params = (typeof str == "string")?(JSON.parse(str)):str;
      callback(params)
    }
    registNativeCallback("systemAbnormal", fn1);
  }


})();

// export default App;
