(function($){$.fn.touchwipe=function(settings){var config={min_move_x:20,min_move_y:20,wipeLeft:function(){},wipeRight:function(){},wipeUp:function(){},wipeDown:function(){},preventDefaultEvents:true};if(settings)$.extend(config,settings);this.each(function(){var startX;var startY;var isMoving=false;function cancelTouch(){this.removeEventListener('touchmove',onTouchMove);startX=null;isMoving=false}function onTouchMove(e){if(config.preventDefaultEvents){e.preventDefault()}if(isMoving){var x=e.touches[0].pageX;var y=e.touches[0].pageY;var dx=startX-x;var dy=startY-y;if(Math.abs(dx)>=config.min_move_x){cancelTouch();if(dx>0){config.wipeLeft(e)}else{config.wipeRight(e)}}else if(Math.abs(dy)>=config.min_move_y){cancelTouch();if(dy>0){config.wipeDown(e)}else{config.wipeUp(e)}}}}function onTouchStart(e){if(e.touches.length==1){startX=e.touches[0].pageX;startY=e.touches[0].pageY;isMoving=true;this.addEventListener('touchmove',onTouchMove,false)}}if('ontouchstart'in document.documentElement){this.addEventListener('touchstart',onTouchStart,false)}});return this}})($);
var CountUp=function(h,b,i,e,g,n){var m=this;m.version=function(){return"1.9.3"};m.options={useEasing:true,useGrouping:true,separator:"",decimal:"",easingFn:c,formattingFn:d,prefix:"",suffix:"",numerals:[]};if(n&&typeof n==="object"){for(var k in m.options){if(n.hasOwnProperty(k)&&n[k]!==null){m.options[k]=n[k]}}}if(m.options.separator===""){m.options.useGrouping=false}else{m.options.separator=""+m.options.separator}var a=0;var l=["webkit","moz","ms","o"];for(var j=0;j<l.length&&!window.requestAnimationFrame;++j){window.requestAnimationFrame=window[l[j]+"RequestAnimationFrame"];window.cancelAnimationFrame=window[l[j]+"CancelAnimationFrame"]||window[l[j]+"CancelRequestAnimationFrame"]}if(!window.requestAnimationFrame){window.requestAnimationFrame=function(s,p){var o=new Date().getTime();var q=Math.max(0,16-(o-a));var r=window.setTimeout(function(){s(o+q)},q);a=o+q;return r}}if(!window.cancelAnimationFrame){window.cancelAnimationFrame=function(o){clearTimeout(o)}}function d(t){var v=(t<0),p,s,r,q,u,o;t=Math.abs(t).toFixed(m.decimals);t+="";p=t.split(".");s=p[0];r=p.length>1?m.options.decimal+p[1]:"";if(m.options.useGrouping){q="";for(u=0,o=s.length;u<o;++u){if(u!==0&&((u%3)===0)){q=m.options.separator+q}q=s[o-u-1]+q}s=q}if(m.options.numerals.length){s=s.replace(/[0-9]/g,function(x){return m.options.numerals[+x]});r=r.replace(/[0-9]/g,function(x){return m.options.numerals[+x]})}return(v?"-":"")+m.options.prefix+s+r+m.options.suffix}function c(p,o,r,q){return r*(-Math.pow(2,-10*p/q)+1)*1024/1023+o}function f(o){return(typeof o==="number"&&!isNaN(o))}m.initialize=function(){if(m.initialized){return true}m.error="";m.d=(typeof h==="string")?document.getElementById(h):h;if(!m.d){m.error="[CountUp] target is null or undefined";return false}m.startVal=Number(b);m.endVal=Number(i);if(f(m.startVal)&&f(m.endVal)){m.decimals=Math.max(0,e||0);m.dec=Math.pow(10,m.decimals);m.duration=Number(g)*1000||2000;m.countDown=(m.startVal>m.endVal);m.frameVal=m.startVal;m.initialized=true;return true}else{m.error="[CountUp] startVal ("+b+") or endVal ("+i+") is not a number";return false}};m.printValue=function(p){var o=m.options.formattingFn(p);if(m.d.tagName==="INPUT"){this.d.value=o}else{if(m.d.tagName==="text"||m.d.tagName==="tspan"){this.d.textContent=o}else{this.d.innerHTML=o}}};m.count=function(p){if(!m.startTime){m.startTime=p}m.timestamp=p;var o=p-m.startTime;m.remaining=m.duration-o;if(m.options.useEasing){if(m.countDown){m.frameVal=m.startVal-m.options.easingFn(o,0,m.startVal-m.endVal,m.duration)}else{m.frameVal=m.options.easingFn(o,m.startVal,m.endVal-m.startVal,m.duration)}}else{if(m.countDown){m.frameVal=m.startVal-((m.startVal-m.endVal)*(o/m.duration))}else{m.frameVal=m.startVal+(m.endVal-m.startVal)*(o/m.duration)}}if(m.countDown){m.frameVal=(m.frameVal<m.endVal)?m.endVal:m.frameVal}else{m.frameVal=(m.frameVal>m.endVal)?m.endVal:m.frameVal}m.frameVal=Math.round(m.frameVal*m.dec)/m.dec;m.printValue(m.frameVal);if(o<m.duration){m.rAF=requestAnimationFrame(m.count)}else{if(m.callback){m.callback()}}};m.start=function(o){if(!m.initialize()){return}m.callback=o;m.rAF=requestAnimationFrame(m.count)};m.pauseResume=function(){if(!m.paused){m.paused=true;cancelAnimationFrame(m.rAF)}else{m.paused=false;delete m.startTime;m.duration=m.remaining;m.startVal=m.frameVal;requestAnimationFrame(m.count)}};m.reset=function(){m.paused=false;delete m.startTime;m.initialized=false;if(m.initialize()){cancelAnimationFrame(m.rAF);m.printValue(m.startVal)}};m.update=function(o){if(!m.initialize()){return}o=Number(o);if(!f(o)){m.error="[CountUp] update() - new endVal is not a number: "+o;return}m.error="";if(o===m.frameVal){return}cancelAnimationFrame(m.rAF);m.paused=false;delete m.startTime;m.startVal=m.frameVal;m.endVal=o;m.countDown=(m.startVal>m.endVal);m.rAF=requestAnimationFrame(m.count)};if(m.initialize()){m.printValue(m.startVal)}};
var winH = $(window).height(), CardPage =  document.getElementById("CardPage");
var pageIndex = 0, pageoffset1 = 0,initBirthday = true, delayUp = false, delayDown = false, initHandle = true, slides = false, page1go = true, page2go = true, page3go = true, page4go = true, page5go = true;

var EntryDays = new CountUp('EntryDays', 0, 0, 0, 2.2);
var PaBirthday = new CountUp('PaBirthday', 0, 0, 0, 3);
//配置项
var hkConfig = {
    //接口API
    api:'//z.pa18.com',
    cdn:'../images/',
    accessToken:'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHBJZCI6ImFwcF9wYV9ocm1fMTAwMDA1IiwidHlwZSI6IjEiLCJleHAiOjE1NDI5NTIyNzEsImlhdCI6MTU0Mjg2NTg3MSwic2lkIjoiUzU1ZmY0NDlhNjczNTVjMDIwMTY3MzlmOGUzZWExZmE1MCJ9.d7UpzmTY-MshA-JSxpKvzV6kPFlhd_fN7lo744IUJHQ',
    wxApi:'//hrx.pingan.com.cn',
    debugger:false
}

var locationHost = location.host.toLocaleUpperCase();
if(locationHost.indexOf("STG1")){
    hkConfig.api = "//z-stg1.pa18.com";
    hkConfig.wxApi = "//hrx-stg1.pingan.com.cn:10869";
}

$("body").touchwipe({
    wipeLeft:function(){
        console.log('left')
    },
    wipeRight:function(){
        if($(".end_page").is(":visible")){
            $(".end_page").fadeOut();
            $(".msg_page").fadeIn();
        }
    },
    wipeDown: function() {
        if(pageIndex == 5) return;
        if(slides){
            pageIndex ++;
            slides = false;
            wipe_down();
        }
    },
    wipeUp: function() {
        if(pageIndex == 0) return;
        if(slides){ 
            pageIndex --;
            slides = false;
            wipe_up();
        }
    },
    min_move_x: 80,
    min_move_y: 80,
    preventDefaultEvents: false
});

var fireStage = new createjs.Stage('fire');
var fireContainer = new createjs.Container();
var spritesheet = new createjs.SpriteSheet({
    "images": [hkConfig.cdn+"ball2.png"],
    "frames": {
        "height": 1000,
        "count": 72,
        "width": 300
    },
    animations: {
        ball1: [1],
        firerun: [0,71,false]
    }
});
var firesheet = new createjs.Sprite(spritesheet, 'firerun');
fireContainer.addChild(firesheet);
fireStage.addChild(fireContainer)

var sandStage = new createjs.Stage('hourglass');
var sandContainer = new createjs.Container();
var spritesheet = new createjs.SpriteSheet({
    "images": [hkConfig.cdn+"sand.png"],
    "frames": {
        "height": 350,
        "count": 36,
        "width": 300
    },
    animations: {
        sand1: [0],
        sandrun: [0,35]
    }
});
var sandsheet = new createjs.Sprite(spritesheet, 'sandrun');
sandContainer.addChild(sandsheet);

sandStage.addChild(sandContainer)

function handleTick(event) {
    if(pageIndex == 1){
        fireStage.update(event);
    }
    if(pageIndex == 2 || delayDown || delayUp){
        sandStage.update(event);
    }
}


$('.p1_round').on('click',function(){
    pageIndex = 1
    var pinganOffset = $('.pinganbuilding').offset();
    var scrollTop = pinganOffset.top - winH + 160;//+= 80;
    $('.page1').addClass('playOut');
    var timer1 = setTimeout(function(){
        if(initHandle){
            initHandle = false;
            createjs.Ticker.addEventListener("tick", handleTick);
        }else{
            firesheet.gotoAndPlay('firerun');
        }
        clearTimeout(timer1);
    },1000)
    var timer2 = setTimeout(function(){
        $('.p2_constellation_box').addClass('play');
        $(".card_page").css({
            'transform':'translate(0,-'+scrollTop+'px)',
        });
        clearTimeout(timer2);
    }, 2000);
    var topTipTimer = setTimeout(function(){
        $(".hand_top_tip").fadeIn();
        clearTimeout(topTipTimer);
    },5500)
    if($(".music_icon").hasClass("music_pause")){
        $(".music_icon").removeClass("music_pause");
        music.play();
    }
    
});

function wipe_down(){
    var pinganOffset = $('.pinganbuilding').offset();
    if(pageIndex == 1){
        return false;
        // var scrollTop = pinganOffset.top - winH + 160;//+= 80;
        // $('.page1').addClass('playOut');
        // var timer1 = setTimeout(function(){
        //     if(initHandle){
        //         initHandle = false;
        //         createjs.Ticker.addEventListener("tick", handleTick);
        //     }else{
        //         firesheet.gotoAndPlay('firerun');
        //     }
        //     clearTimeout(timer1);
        // },1000)
        // var timer2 = setTimeout(function(){
        //     $('.p2_constellation_box').addClass('play');
        //     $(".card_page").css({
        //         'transform':'translate(0,-'+scrollTop+'px)',
        //     });
        //     clearTimeout(timer2);
        // }, 2000);
    }else if(pageIndex == 2){
        delayDown = true;
        $('.p2_constellation_box').addClass('playOut');
        pageoffset1 = pinganOffset.top - 1;
        var scrollTop = Math.abs($('.card_page').css('transform').replace(/[^0-9\-\.,]/g,'').split(',')[5]) + pageoffset1;
        if(!initHandle){
            sandsheet.gotoAndPlay('sandrun');
        }
        var timer3 = setTimeout(function(){
            $(".card_page").css({
                'transform':'translate(0,-'+scrollTop+'px)',
            });
            $('.p3_ele').addClass('play');
            clearTimeout(timer3);
        },1200)
        $(".hand_top_tip").fadeOut();

    }else if(pageIndex == 3){
        var scrollTop = Math.abs($('.card_page').css('transform').replace(/[^0-9\-\.,]/g,'').split(',')[5]) + 603;
        $('.p3_ele').addClass('playOut');
        var timer4 = setTimeout(function(){
            $(".card_page").css({
                'transform':'translate(0,-'+scrollTop+'px)',
            });
            $('.pinganbuilding').addClass('play');
            clearTimeout(timer4);
        },1800)
    }else if(pageIndex == 4){
        $('.pinganbuilding').addClass('playOut');
        $('.p5_madesc').show();
        if($('.pinganbuilding').hasClass('playBacks')){
            $('.pinganbuilding').removeClass('playBacks')
            PaBirthday.update(PartnerBirthday);
        }
        if(initBirthday){
            initBirthday = false;
            GM.init('Birthday');
            GM.goToScene('BIRTHDAY');
        }
    }else if(pageIndex == 5){
        $('.p5_madesc').fadeOut(800);
        $('.pinganbuilding').addClass('transit');
        var timer5 = setTimeout(function(){
            $('.birthday').fadeIn(1200);
            GM.playing = true;
            clearTimeout(timer5);
        },2000)
    }
}

//跳过
$(".jump").on("click",function(){
    $("#CardPage").fadeOut();
    $(".birthday").fadeIn();
    initBirthday = 2;
    GM.init('Birthday');
    GM.goToScene('BIRTHDAY');
})

function wipe_up(){
    if(pageIndex == 0){
        $('.p2_constellation_box').addClass('playOut');
        var timer6 = setTimeout(function(){
            $(".card_page").css({
                'transform':'translate(0,0)'
            });
            clearTimeout(timer6);
        },1200);
        firesheet.gotoAndStop('ball1');
        $(".hand_top_tip").fadeOut();
    }else if(pageIndex == 1){
        delayUp = true;
        var scrollTop = Math.abs($('.card_page').css('transform').replace(/[^0-9\-\.,]/g,'').split(',')[5]) - pageoffset1;
        $('.p3_ele').addClass('playOut');
        var timer7 = setTimeout(function(){
            $(".card_page").css({
                'transform':'translate(0,-'+scrollTop+'px)'
            });
            $('.p2_constellation_box').addClass('play')
            clearTimeout(timer7);
        },1400)
    }else if(pageIndex == 2){
        if($('.pinganbuilding').hasClass('playOut playBacks')){
            $('.pinganbuilding').removeClass('playOut')
        }
        var scrollTop = Math.abs($('.card_page').css('transform').replace(/[^0-9\-\.,]/g,'').split(',')[5]) - 603;
        $('.pinganbuilding').addClass('playBack');
        var timer8 = setTimeout(function(){
            $(".card_page").css({
                'transform':'translate(0,-'+scrollTop+'px)'
            });
            $('.p3_ele').addClass('play');
            clearTimeout(timer8);
        },2000);
        EntryDays.reset();
    }else if(pageIndex == 3){
        // PaBirthday.reset();
        $('.p5_madesc').fadeOut(800);
        $('.pinganbuilding').addClass('playBacks');
        // PaBirthday.update(PartnerBirthday);
        page4go = true;
        page5go = true
    }
}

CardPage.addEventListener('transitionend', function(){
    if(pageIndex == 0){
       $('.page1').addClass('play');
       $('.p3_ele').removeClass('play playOut');
       $('.p2_constellation_box').removeClass('play playOut');
    }else if(pageIndex == 1){
        $('.page1').removeClass('play playOut');
        $('.p3_ele').removeClass('play playOut');
        EntryDays.reset();
        delayUp = false;
        sandsheet.gotoAndStop('sand1');
    }else if(pageIndex == 2){
        $('.pinganbuilding').removeClass('play playBack');
        $('.p2_constellation_box').removeClass('play playOut')
        PaBirthday.reset();
        EntryDays.update(RegisterDays);
    }else if(pageIndex == 3){
        $('.p3_ele').removeClass('play playOut');
        PaBirthday.update(PartnerBirthday);
        delayDown = false;
    }
    page1go = true; page2go = true; page3go = true; page4go = true; page5go = true;
}, false);

document.getElementById("Page1End").addEventListener('animationend', function(){
    if(page1go){
        page1go = false;
        slides = true;
    }
}, false);

document.getElementById("Page2End").addEventListener('animationend', function(){
    if(page2go){
        page2go = false;
        slides = true;
    }
}, false);

document.getElementById("Page3End").addEventListener('animationend', function(){
    if(page3go){
        page3go = false;
        slides = true;
    }
}, false);

document.getElementById("Page4End").addEventListener('animationend', function(){
    if(page4go){
        page4go = false;
        slides = true;
    }
}, false);


document.getElementById("Page5End").addEventListener('animationend', function(){
    if(page5go){
        page5go = false;
        slides = true;
    }
}, false);

$(".p7_click_box").on("click",function(){
    $(".birthday,#CardPage").fadeOut(1200);
    $(".msg_page").css("opacity",1).fadeIn();
    return false;
});
var music = document.getElementById("music");




$(".music_icon").on("click",function(){
    if($(this).hasClass("music_pause")){
        $(this).removeClass("music_pause");
        music.play();
    }else{
        $(this).addClass("music_pause");
        music.pause();
    }
})

'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

(function (win) {

    var gameStage = void 0;

    // 基本
    var __extends = function __extends(obj1, obj2) {
        Object.keys(obj2).forEach(function (e) {
            if (obj2.hasOwnProperty(e)) {
                obj1[e] = obj2[e];
            }
        });
        var c = function c() {
            this.constructor = obj1;
        };
        c.prototype = obj2.prototype;
        obj1.prototype = new c();
    };

    var __setMethods = function __setMethods(object, key, value) {
        if ((typeof key === 'undefined' ? 'undefined' : _typeof(key)) === 'object') {
            for (var item in key) {
                __setMethods(object, item, key[item]);
            }
        } else if (typeof key === 'string') {
            object.prototype[key] = value;
        };
    };

    // 工具方法
    var toolkits = function () {
        var a = {
            BGColor: '#000',
            FGColor: '#FFF',
            LOADINGTEXT: '前方高能... ',
            PIXEL_RATIO: window.devicePixelRatio || 2,
            ASSETS_WIDTH: 750,
            ASSETS_HEIGHT: 1206, //1206
            getRandom: function getRandom(max, min) {
                //max>x≥min
                max = max || 1;
                min = min || 0;
                return Math.floor(Math.random() * (max - min)) + min;
            },
            num2Str: function num2Str(num, length, strInstead) {
                // 数字转成固定长度的字符,ex: 数字20转成4位字符串 => '0020'
                if (typeof num == 'number' && num === num) {
                    num = num.toString();
                }

                strInstead = strInstead || '0';

                if (typeof num !== 'string') {
                    return strInstead;
                };
                if (length > num.length) {
                    for (var i = 0, l = length - num.length; i < l; i++) {
                        num = strInstead + num;
                    }
                };

                return num;
            }
        };
        a.PROPORTION = a.ASSETS_WIDTH / a.ASSETS_HEIGHT, //比例

        // a.SCALE = 1;
        a.resize = function () {
            var w = window.innerWidth,
                h = window.innerHeight;

            if (w / h > a.ASSETS_WIDTH / a.ASSETS_HEIGHT) {
                a.CANVAS_WIDTH = Math.round(a.ASSETS_WIDTH * h / a.ASSETS_HEIGHT);
                a.CANVAS_HEIGHT = h;
            } else {
                a.CANVAS_WIDTH = w;
                a.CANVAS_HEIGHT = Math.round(a.ASSETS_HEIGHT * w / a.ASSETS_WIDTH);
            }
        };
        a.resize();
        return a;
    }();

    // 舞台相关
    var StageManager = function () {
        function stage(canvasid) {
            console.log('舞台');
            var that = this;
            gameStage = that;
            that.scenesConstainer = new createjs.Container();
            that.timeDevider = 1;
            that.lastTime = 0;
            that.paused = false;
            that.scenes = new Array();
            that.canvas = document.getElementById(canvasid);
            that.stage = new createjs.Stage(that.canvas);
            createjs.Touch.enable(that.stage);
            createjs.Ticker.setFPS(60);
            createjs.Ticker.addEventListener("tick", function (f) {
                if (that.isPaused()) {
                    return;
                };
                return that.update(f);
            });
            that.stage.addChild(that.scenesConstainer);
            that.setRect(); //设置宽高

            var event_resize = ['viewportready', 'viewportchange', 'orientationchange', 'resize'];
            var __t;
            event_resize.forEach(function (item, i) {
                window.addEventListener(item, function () {
                    that.handleResize()
                });
            });
            // 横屏则暂停
            if (typeof window.orientation == 'number' && window.orientation != 0) {
                this.pause();
            };
        }
        __setMethods(stage, {
            goon: function goon() {
                this.paused = false;
                return this;
            },
            pause: function pause() {
                this.paused = true;
                return this;
            },
            isPaused: function isPaused() {
                return this.paused;
            },
            handleResize: function handleResize() {
                this.setRect();
            },
            setRect: function setRect() {
                var canvas = this.canvas;

                toolkits.resize();

                canvas.width = toolkits.ASSETS_WIDTH;
                canvas.height = toolkits.ASSETS_HEIGHT;
                canvas.style.width = toolkits.CANVAS_WIDTH + 'px';
                canvas.style.height = toolkits.CANVAS_HEIGHT + 'px';
                return this;
            },
            update: function update(d) {
                if (this.scenes.length != 0) {
                    var b = this.scenes[this.scenes.length - 1];
                    if (!b.isInited()) {
                        b.init();
                    }
                    var c = createjs.Ticker.getTime();
                    var e = c - this.lastTime;
                    this.lastTime = c;
                    b.update(e * 0.001 / this.timeDevider);
                }
                this.stage.update(d);
            },
            replaceAllSceneWith: function replaceAllSceneWith(b) {
                while (this.scenes.length != 0) {
                    this.popScenes();
                }
                this.pushScene(b);
                return this;
            },
            pushScene: function pushScene(b) {
                if (this.scenes[this.scenes.length - 1] === b) {
                    return this;
                };
                this.scenes.push(b);
                this.scenesConstainer.addChild(b);
                return this;
            },
            popScenes: function popScenes(key, value) {
                var that = this;
                if (this.scenes.length != 0) {
                    if (!key && !value) {
                        this.scenesConstainer.removeChild(this.scenes[this.scenes.length - 1]);
                        this.scenes.pop();
                    } else {
                        if (!key || !value) {
                            return;
                        };
                        this.scenes = this.scenes.filter(function (item) {
                            var isMatched = item[key] === value;
                            isMatched && that.scenesConstainer.removeChild(item);
                            return !isMatched;
                        });
                    };
                }
                return this;
            },
            popScenesExcept: function popScenesExcept(key, value) {
                var that = this;
                if (!key || !value) {
                    return;
                };
                if (this.scenes.length != 0) {
                    this.scenes = this.scenes.filter(function (item) {
                        var isMatched = item[key] === value;
                        !isMatched && that.scenesConstainer.removeChild(item);
                        return isMatched;
                    });
                }
                return this;
            }
        });
        return stage;
    }();
    // 场景通用的扩展模块
    var BaseScene = function (c) {
        __extends(_scene, c);
        function _scene() {
            c.call(this);
            this.liveTime = 0;
            // this.gui = new Array();
            this.gameObjects = new Array();
            this.initiliazed = false;
        }
        __setMethods(_scene, {
            init: function init() {
                this.initiliazed = true;
            },
            isInited: function isInited() {
                return this.initiliazed;
            },
            update: function update(d) {
                var that = this;
                that.liveTime += d;
                var newGameObjects = [];
                that.gameObjects.forEach(function (item, i) {
                    if (!that.isGameOver && !that.isPaused) {
                        item.update(d);
                    }
                    if (item.isDead()) {
                        item.onDead();
                    } else {
                        newGameObjects.push(item);
                    }
                });
                that.gameObjects.splice(0, that.gameObjects.length);
                newGameObjects.forEach(function (item, i) {
                    that.gameObjects[i] = item;
                });
            },
            addObject: function addObject(obj_game) {
                this.gameObjects.push(obj_game);
            },
            addObjectAt: function addObjectAt(obj_game, ctn) {
                this.gameObjects.push(obj_game);
                (ctn || this).addChild(obj_game);
            }
        });

        return _scene;
    }(createjs.Container);

    // 游戏角色、元素相关
    var GameObject = function (a) {
        __extends(b, a);

        function b() {
            a.call(this);
            this.liveTime = 0;
            this.killed = false;
        }
        __setMethods(b, {
            update: function update(c) {
                this.liveTime += c;
            },
            kill: function kill() {
                this.killed = true;
            },
            isDead: function isDead() {
                return this.killed;
            },
            onDead: function onDead() {
                if (this.parent) {
                    this.parent.removeChild(this);
                }
            }
        });
        return b;
    }(createjs.Container);

    // 资源管理
    var AssetsLoader = function (b) {

        __extends(a, b);
        function a(resources) {
            console.log('资源');
            b.call(this);
            var that = this;
            that.loader = new createjs.LoadQueue();
            that.res = resources || {};

            createjs.EventDispatcher.initialize(a.prototype);

            that.loader.installPlugin(createjs.Sound);
            createjs.Sound.initializeDefaultPlugins();
            that.soundsList = {};

            that.bg = new createjs.Shape();
            //that.bg.graphics.beginFill(toolkits.BGColor).drawRect(0, 0, toolkits.ASSETS_WIDTH, toolkits.ASSETS_HEIGHT).endFill();
            that.bg.graphics.beginRadialGradientFill(["#fdfdfd","#f3f3f3"], [0, 1], toolkits.ASSETS_WIDTH/2, toolkits.ASSETS_WIDTH/2, 0, toolkits.ASSETS_WIDTH/2, toolkits.ASSETS_WIDTH/2, 2000).drawRect(0,0,toolkits.ASSETS_WIDTH,toolkits.ASSETS_HEIGHT);
 
            that.addChild(that.bg);
            
            that.loader.on("complete", function (e) {
                that.handleComplete(e);
            });
            that.loader.on("progress", function (e) {
                that.handleProgress(e);
            });

            that.alpha = 0;
            that.sceneName = 'loader';
        }
        __setMethods(a, {
            update: function update() {},
            resetUI: function resetUI() {
                this.loadPercent && (this.removeAllChildren(), this.loadPercent = undefined);
                this.addChild(this.bg);
                return this;
            },
            transitionStart: function transitionStart(cb) {
                console.log('transitionStart');
                this.resetUI();
                this.alpha = 0;
                gameStage.pushScene(this);
                createjs.Tween.get(this).to({ alpha: 1 }, 300, createjs.Ease.linear).call(function () {
                    gameStage.popScenes('sceneName', 'loader');
                    typeof cb === 'function' && cb();
                });
                return this;
            },
            transitionEnd: function transitionEnd(cb) {
                console.log('transitionEnd');
                this.alpha = 1;
                gameStage.pushScene(this);
                createjs.Tween.get(this).to({ alpha: 0 }, 300, createjs.Ease.linear).call(function () {
                    gameStage.popScenes('sceneName', 'loader');
                    typeof cb === 'function' && cb();
                });
                return this;
            },
            preload: function preload(newScene) {
                var _this = this;
                console.log('preload');
                var resources = this.res[newScene.resKey];
                if (typeof newScene.startDraw !== 'function') {
                    newScene.startDraw = function () {};
                }
                if (!resources || resources['res'].length == 0 || resources.isLoaded) {
                    // 如果没有本场景的资源或本场景资源已经加载了
                    // 则直接不输出loading，直接过渡动画到下一场景
                    this.transitionStart(function () {
                        gameStage.replaceAllSceneWith(newScene);
                        newScene.startDraw();
                        _this.transitionEnd(function () {
                            newScene.startPlay();
                        });
                    });
                } else {
                    this.newScene = newScene;
                    this.newSceneRes = resources;
                    this.handleStart();
                }
            },
            handleStart: function handleStart(e) {
                var _this2 = this;
                console.log('handleStart');
                this.transitionStart(function () {
                    gameStage.replaceAllSceneWith(_this2.newScene);
                    gameStage.pushScene(_this2);
                    _this2.loader.loadManifest(_this2.newSceneRes['res']);
                });
            },
            handleComplete: function handleComplete(e) {
                console.log('handleComplete');
                var _this3 = this;
                if (_this3.newScene) {
                    _this3.res[_this3.newScene.resKey].isLoaded = true;
                    // 即将淡出过渡动画时，先绘制
                    _this3.newScene.startDraw();

                    // 点击进入下一个场景
                    // var text = new createjs.Text('点击进入', '24px Arial', toolkits.FGColor)
                    // _this3.addChild(text)
                    // this.loadPercent.text = '点击进入'
                    var a = false
                    // _this3.on('click', function(){
                    //     if (a) {return}
                    //     a = true
                        _this3.transitionEnd(function () {
                            // 过渡动画完全淡出后
                            _this3.newScene.startPlay();
                            if(initBirthday == 2){
                                $('.birthday').show();
                                $('.loading').fadeOut(300,function(){
                                   GM.playing = true;
                                });
                            }
                        });
                    //})
                    
                    
                } else {
                    // this.callback();
                };
            },
            handleProgress: function handleProgress(e) {
                // console.log('加载中')
                // var TEXT = (toolkits.LOADINGTEXT || '') + (e.loaded * 100).toFixed(0) + "%";
                // // var ldcycle = this.getResult('loading-cycle')
                // // if (ldcycle && !this.loading_cycle) {
                // //     ldcycle = this.getBitmapCenter('loading-cycle');
                // //     ldcycle.y -= 80
                // //     this.loading_cycle = ldcycle;
                // //     this.addChild(ldcycle)
                // // }

                // // var ldcycleb = this.getResult('loading-cycleb')
                // // if (ldcycleb && !this.loading_cycleb) {
                // //     ldcycleb = this.getBitmapCenter('loading-cycleb')
                // //     ldcycleb.y -= 80
                // //     createjs.Tween.get(ldcycleb,{loop:true})
                // //     .to({alpha:1, scaleX:1.2, scaleY:1.2},1000)
                // //     .to({alpha:0, scaleX:1.4, scaleY:1.4},1000,createjs.Ease.linear).wait(300);
                // //     this.loading_cycleb = ldcycleb;
                // //     this.addChild(ldcycleb);
                // // }
                // if (this.loadPercent) {
                //     this.loadPercent.text = TEXT;
                // } else {
                //     this.loadPercent = new createjs.Text(TEXT, '26px Arial', toolkits.FGColor);
                //     this.loadPercent.y = toolkits.ASSETS_HEIGHT / 2;
                //     this.loadPercent.x = toolkits.ASSETS_WIDTH / 2;
                //     this.loadPercent.textAlign = 'center';
                //     this.addChild(this.loadPercent);
                // };
            },
            getResult: function getResult(c) {
                return this.loader.getResult(c);
            },
            getButton: function getButton(c, fn, sprite) {
                // console.log('getButton');
                fn = typeof fn == 'function' ? fn : function () {};
                var btn = this.getBitmapCenter(c);
                switch (sprite) {
                    case 'sprite':
                        btn = this.getSprite('btns');
                        btn.gotoAndStop(c);
                        break;
                    case 'bitmap':
                    default:
                        btn = this.getBitmapCenter(c);
                }
                var _b = btn.getBounds();
                btn.x = toolkits.ASSETS_WIDTH / 2;
                btn.y = toolkits.ASSETS_HEIGHT / 2;
                btn.regX = _b.width / 2;
                btn.regY = _b.height / 2;

                var scale = function scale(num) {
                    if (typeof num !== 'number') {
                        num = 1;
                    }
                    createjs.Tween.get(btn).to({ scaleX: num, scaleY: num }, 30);
                };
                btn.on('mousedown', function () {
                    scale(0.95);
                });
                btn.on('click', function (e) {
                    fn.call(btn, e);
                    btn.clicked = true;
                });
                btn.on('pressmove', function () {
                    scale(1);
                });
                btn.on('pressup', function () {
                    scale(1);
                });
                return btn;
            },
            getBitmap: function getBitmap(c) {
                // console.log('getBitmap');
                return new createjs.Bitmap(this.getResult(c));
            },
            getBitmapCenterX: function getBitmapCenterX(c) {
                // console.log('getBitmapCenterX');
                var d = this.getBitmap(c);
                if (!d || !d.getBounds()) {
                    console.log(c, d);return d;
                };
                d.regX = d.getBounds().width / 2;
                d.x = toolkits.ASSETS_WIDTH / 2;
                return d;
            },
            getBitmapCenter: function getBitmapCenter(c) {
                // console.log('getBitmapCenter');
                var d = this.getBitmap(c);
                if (!d || !d.getBounds()) {
                    console.log(c, d);return d;
                };
                d.regX = d.getBounds().width / 2;
                d.regY = d.getBounds().height / 2;
                d.x = toolkits.ASSETS_WIDTH / 2;
                d.y = toolkits.ASSETS_HEIGHT / 2;
                return d;
            },
            getSpriteCenterX: function getSpriteCenterX(c, d) {
                // console.log('getSpriteCenterX');
                var e = this.getSprite(c, d);
                e.regX = e.getBounds().width / 2;
                e.x = toolkits.ASSETS_WIDTH / 2;
                return e;
            },
            getSpriteCenter: function getSpriteCenter(c, d) {
                // console.log('getSpriteCenter');
                var e = this.getSprite(c, d);
                e.regX = e.getBounds().width / 2;
                e.regY = e.getBounds().height / 2;
                e.x = toolkits.ASSETS_WIDTH / 2;
                e.y = toolkits.ASSETS_HEIGHT / 2;
                return e;
            },
            getSpriteSheet: function getSpriteSheet(c) {
                console.log('getSpriteSheet');
                var d = new createjs.SpriteSheet(this.getResult(c));
                return d;
            },
            getSprite: function getSprite(c, d) {
                console.log('getSprite');
                var sheet = this.getSpriteSheet(c);
                var e = new createjs.Sprite(sheet, d);
                if (!e || !e.getBounds()) {
                    console.log(c, d);
                };
                e.stop();
                return e;
            },
            getAudio: function getAudio(c, newOne) {
                console.log('getAudio');
                var audio = this.loader.getResult(c);
                if (this.soundsList[c] && !newOne) {
                    audio = this.soundsList[c];
                } else if (audio) {
                    audio = createjs.Sound.createInstance(c);
                    this.soundsList[c] = audio;
                } else {
                    console.log('error: no such a audio of "' + c + '"');
                    audio = { play: function play() {}, stop: function stop() {} };
                }
                return audio;
            },
            getPricent: function getPricent(start,target,order){
                var pricent = order ? 1 - ((target - start) / target) :  (target - start) / target;
                return pricent;
            }
        });
        return a;
    }(BaseScene);

    var gameManager = function () {
        var _scenes = {};
        var _gameObjects = {};
        var resources = {};
        var _cacheData = {};
        var currentScene = void 0;
        var currentStage = void 0;
        var gameAssets = void 0;
        var gameStage = void 0;
        var _LSHolder = {
            _data: {},
            setItem: function setItem(key, value) {
                this._data[key] = value;
            },
            getItem: function getItem(key) {
                return this._data[key];
            },
            removeItem: function removeItem(key) {
                delete this._data[key];
            }
        };
        var LSManager = function () {
            var mainkey = '';
            var _LSHolder = {
                _data: {},
                setItem: function setItem(key, value) {
                    this._data[key] = value;
                },
                getItem: function getItem(key) {
                    return this._data[key];
                },
                removeItem: function removeItem(key) {
                    delete this._data[key];
                }
            };
            var ls = localStorage || _LSHolder;
            try {
                ls.setItem('game_test', '1');
                ls = ls.getItem('game_test') === '1' ? ls : _LSHolder;
                ls.removeItem('game_test');
            } catch (e) {
                ls = _LSHolder;
            }
            var getData = function getData() {
                return JSON.parse(ls.getItem(mainkey) || '{}');
            };

            return {
                setItem: function setItem(key, val) {
                    if (!mainkey) {
                        return this;
                    }
                    var _data = getData();
                    _data[key] = val;
                    ls.setItem(mainkey, JSON.stringify(_data));
                    return this;
                },
                getItem: function getItem(key) {
                    if (!mainkey) {
                        return null;
                    }
                    var _data = getData();
                    return _data[key];
                },
                removeItem: function removeItem(key) {
                    if (!mainkey) {
                        return this;
                    }
                    var _data = getData();
                    delete _data[key];
                    ls.setItem(mainkey, JSON.stringify(_data));
                    return this;
                },
                clear: function clear(key) {
                    if (!mainkey) {
                        return this;
                    }
                    var _data = getData();
                    delete _data[key];
                    ls.setItem(mainkey, JSON.stringify(_data));
                    return this;
                },
                init: function init(MAINKEY) {
                    mainkey = MAINKEY;
                    ls.getItem(mainkey) || ls.setItem(mainkey, '{}');
                    return this;
                }
            };
        }();
        return {
            toolkits: toolkits,
            LS: LSManager,
            cache: {
                get: function get(key) {
                    return typeof 'key' === 'string' ? _cacheData[key] : undefined;
                },
                set: function set(key, value) {
                    typeof 'key' === 'string' && (_cacheData[key] = value);
                    return this;
                }
            },
            getObject: function getObject(objectName) {
                if (!_gameObjects || !_gameObjects[objectName]) {
                    return null;
                }

                for (var _len = arguments.length, arg = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
                    arg[_key - 1] = arguments[_key];
                }

                return new (Function.prototype.bind.apply(_gameObjects[objectName], [null].concat(arg)))();
            },
            addObject: function addObject(objectName, methods) {
                if (!_gameObjects) {
                    _gameObjects = {};
                }
                _gameObjects[objectName] = function (a) {
                    __extends(b, a);
                    function b() {
                        a.call(this);
                        typeof this.init === 'function' && this.init.apply(this, arguments);
                    }
                    __setMethods(b, methods);
                    return b;
                }(GameObject);
                return this;
            },
            addScene: function addScene(sceneName, methods, res) {
                if (typeof sceneName !== 'string' || (typeof methods === 'undefined' ? 'undefined' : _typeof(methods)) !== 'object') {
                    return this;
                };

                _scenes[sceneName] = function (b) {
                    __extends(_scene, b);
                    function _scene() {
                        console.log('Play场景');
                        var that = this;
                        b.call(this);
                        var bg = new createjs.Shape();
                        bg.graphics.beginFill(toolkits.BGColor).drawRect(0, 0, toolkits.ASSETS_WIDTH, toolkits.ASSETS_HEIGHT).endFill();

                        that.addChild(bg);
                        that.resKey = sceneName;
                        that.sceneName = sceneName;
                        gameAssets.preload(that);
                    }

                    var newUpdateFn = typeof methods.update === 'function' ? methods.update : function () {};
                    var methods_default = {
                        startDraw: function startDraw() {},
                        // 资源加载结束时
                        startPlay: function startPlay() {},
                        // 资源加载结束且过渡动画完全退出时
                        update: function update(r) {
                            b.prototype.update.call(this, r);
                            newUpdateFn.call(this, r, b);
                        }
                    };
                    Object.keys(methods_default).forEach(function (item) {
                        if (!methods[item] || item === 'update') {
                            methods[item] = methods_default[item];
                        }
                    });
                    __setMethods(_scene, methods);
                    return _scene;
                }(BaseScene);

                res && res instanceof Array && (resources[sceneName] = { 'res': res });

                return this;
            },
            goToScene: function goToScene(sceneName) {
                var _scene = _scenes[sceneName];
                if (!_scene) {
                    return undefined;
                };
                currentScene = new _scene();
                return currentScene;
            },
            getScene: function getScene(sceneName) {
                return _scenes[sceneName];
            },
            getCurrentScene: function getCurrentScene() {
                return currentScene;
            },
            getRes: function getRes(resName) {
                return resName && resources[resName] ? resources[resName] : resources;
            },
            init: function init(id, cb) {
                currentStage = this.stage = new StageManager(id);
                gameAssets = this.assets = new AssetsLoader(resources);
                typeof cb === 'function' && cb();
            }
        };
    }();

    win.gameManager = gameManager;
})(window);


(function (win) {
    var GM = gameManager;
    GM.toolkits.BGColor = "#f6f6f6";
    GM.toolkits.FGColor = "#333333";
    GM.toolkits.LOADINGTEXT = "";
    GM.toolkits.resize = function () {
        var w = window.innerWidth,
            h = window.innerHeight;
            GM.toolkits.CANVAS_WIDTH = w;
            GM.toolkits.CANVAS_HEIGHT = h
            GM.toolkits.ASSETS_HEIGHT = Math.round(GM.toolkits.ASSETS_WIDTH * h / w)
    }
    // GM.addScene('PLAY', {
    //     startDraw: function () {
    //         console.log('startDraw');
    //     },
    //     startPlay: function () {
    //         var me = this;

    //         me.ctn = new createjs.Container();

    //         me.bg = GM.assets.getBitmap('birthday');

    //         me.addChild(me.bg, me.ctn);
    //     }
    // });


    GM.addScene('BIRTHDAY', {
        startPlay: function () {
            var me = this;

            me.ctn = new createjs.Container();

            me.bg = GM.assets.getBitmap('birthday');

            me.addChild(me.bg, me.ctn);
            // if(GM.playing){
                
            // }
            GM.playing = false;

        },
        update: function update(r) {
            var me = this;
            if(GM.playing){
                GM.playing = false;
                var fireenter = (function(){
                    var ctn = new createjs.Container();
                    var fe = GM.assets.getSpriteCenter('fireenter');
                    fe.x = 300;
                    fe.y = 230;
                    fe.gotoAndPlay('fireenter');
                    setTimeout(function(){
                        var fireworks = (function(){
                            var ctn = new createjs.Container();
                            var fws = GM.assets.getSprite('fireworks');
                            fws.scaleX = fws.scaleY = 2;
                            fws.x = 0;
                            fws.y = 0;
                            fws.gotoAndPlay('fireworks');
                            
                            ctn.addChild(fws)
                            me.ctn.addChild(ctn)
                        })();
                    },1000)
                    fe.on('click', function(){
                        $(".msg_page").css("opacity",1).fadeIn();
                    })
                    $('#CanvasTap').show();
                    ctn.addChild(fe)
                    me.ctn.addChild(ctn)
                    return this
                })();
            }
            
        }
    },[
        { id: 'birthday', src: hkConfig.cdn+'p7bg1.jpg' },
        { id: 'fireenter', src: hkConfig.cdn+'fireenter.json' },
        { id: 'fireworks', src: hkConfig.cdn+'fireworks.json' }
    ])

    win.GM = GM;

})(window);

//获取url参数
function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"); 
    var r = window.location.search.substr(1).match(reg); 
    if (r != null) return unescape(r[2]);
    return null; 
}


// GM.init('game');
// GM.goToScene('PLAY');

var pics = [
    hkConfig.cdn+"end_icon_replay.png",
    hkConfig.cdn+"icon_hand.png",
    hkConfig.cdn+"p2_cloud4.png",
    hkConfig.cdn+"p4cloud22.png",
    hkConfig.cdn+"ball1.png",
    hkConfig.cdn+"end_icon_share.png",
    hkConfig.cdn+"icon_moments.png",
    hkConfig.cdn+"p2_constellation.png",
    hkConfig.cdn+"p5sign.png",
    hkConfig.cdn+"ball2.png",
    hkConfig.cdn+"end_light.png",
    hkConfig.cdn+"icon_music.png",
    hkConfig.cdn+"p2_shadow_point.png",
    hkConfig.cdn+"p7balloon1.png",
    hkConfig.cdn+"bdlr_bg.png",
    hkConfig.cdn+"end_logo.png",
    hkConfig.cdn+"ld_envelope.png",
    hkConfig.cdn+"p2_yello_point.png",
    hkConfig.cdn+"p7balloon2.png",
    hkConfig.cdn+"bdtb_bg.png",
    hkConfig.cdn+"end_page1.jpg",
    hkConfig.cdn+"ld_envelope_bottom.png",
    hkConfig.cdn+"p3b1.png",
    hkConfig.cdn+"p7balloon3.png",
    hkConfig.cdn+"blacksky.jpg",
    hkConfig.cdn+"end_slogan.png",
    hkConfig.cdn+"ld_envelope_top.png",
    hkConfig.cdn+"p3b2.png",
    hkConfig.cdn+"p7bg1.jpg",
    hkConfig.cdn+"fireenter.json",
    hkConfig.cdn+"ld_envelope_top1.png",
    hkConfig.cdn+"p3b3.png",
    hkConfig.cdn+"p7gift1.png",
    hkConfig.cdn+"cake_bg.png",
    hkConfig.cdn+"fireenter.png",
    hkConfig.cdn+"ld_heart.gif",
    hkConfig.cdn+"p3b4.png",
    hkConfig.cdn+"pagination_bg1.png",
    hkConfig.cdn+"candle.png",
    hkConfig.cdn+"fireenter1.png",
    hkConfig.cdn+"ld_heart.png",
    hkConfig.cdn+"p3b5.png",
    hkConfig.cdn+"pink_balloon.png",
    hkConfig.cdn+"cherry_bg.png",
    hkConfig.cdn+"fireworks.json",
    hkConfig.cdn+"ld_heart1.gif ",
    hkConfig.cdn+"p3b6.png",
    hkConfig.cdn+"quotes_end.png",
    hkConfig.cdn+"colleagues_bg.png",
    hkConfig.cdn+"fireworks.png",
    hkConfig.cdn+"ld_round.png",
    hkConfig.cdn+"p3b7.png",
    hkConfig.cdn+"quotes_start.png",
    hkConfig.cdn+"crane.png",
    hkConfig.cdn+"fireworks1.png",
    hkConfig.cdn+"mrma.png",
    hkConfig.cdn+"p3cloud.png",
    hkConfig.cdn+"sand.png",
    hkConfig.cdn+"default.png",
    hkConfig.cdn+"hand1.png",
    hkConfig.cdn+"p3cloud1.png",
    hkConfig.cdn+"sandstatic.png",
    hkConfig.cdn+"dot.png",
    hkConfig.cdn+"hand2.png",
    hkConfig.cdn+"msg_balloon1.png",
    hkConfig.cdn+"p3cloud2.png",
    hkConfig.cdn+"sys_page_house.png",
    hkConfig.cdn+"end_bubble.png",
    hkConfig.cdn+"hat.png",
    hkConfig.cdn+"p3cloud3.png",
    hkConfig.cdn+"to_icon.png",
    hkConfig.cdn+"end_cake.png",
    hkConfig.cdn+"hourglass.png",
    hkConfig.cdn+"msg_cake_bg.png",
    hkConfig.cdn+"p4b1.png",
    hkConfig.cdn+"voice_icon.png",
    hkConfig.cdn+"end_cake1.png",
    hkConfig.cdn+"hourglass1.png",
    hkConfig.cdn+"msg_pic.jpg",
    hkConfig.cdn+"p4b2.png",
    hkConfig.cdn+"voice_pause.png",
    hkConfig.cdn+"end_cake2.png",
    hkConfig.cdn+"hourglass_body.png",
    hkConfig.cdn+"msg_topballoon_bg.png",
    hkConfig.cdn+"p4b3.png",
    hkConfig.cdn+"voice_play.png",
    hkConfig.cdn+"end_cake3.png",
    hkConfig.cdn+"hourglass_header.png",
    hkConfig.cdn+"p2_cloud1.png",
    hkConfig.cdn+"p4b4.png",
    hkConfig.cdn+"whitesky.png",
    hkConfig.cdn+"end_cake_bg.png",
    hkConfig.cdn+"hrx_logo.png",
    hkConfig.cdn+"p2_cloud2.png",
    hkConfig.cdn+"p4b5.png",
    hkConfig.cdn+"end_cherry.png",
    hkConfig.cdn+"icon_ball.png",
    hkConfig.cdn+"p2_cloud21.png",
    hkConfig.cdn+"p4cloud1.png",
    hkConfig.cdn+"end_fire.png",
    hkConfig.cdn+"icon_friends.png",
    hkConfig.cdn+"p2_cloud3.png"

]

//_loading
function _loadImages(pics, callback, len) {
    len = len || pics.length;
    if (pics.length) {
        var IMG = new Image(),
            picelem = pics.shift();

        if (window._pandaImageLoadArray) {
            window._pandaImageLoadArray = window._pandaImageLoadArray
        } else {
            window._pandaImageLoadArray = [];
        }
        window._pandaImageLoadArray.push(picelem);
        IMG.src = picelem;
        // 从数组中取出对象的一刻，就开始变化滚动条
        _drawLoadProgress(window._pandaImageLoadArray.length / (len * len));
        // 缓存处理
        if (IMG.complete) {
            window._pandaImageLoadArray.shift();
            return _loadImages(pics, callback, len);
        } else {
            // 加载处理
            IMG.onload = function() {
                    window._pandaImageLoadArray.shift();
                    IMG.onload = null; // 解决内存泄漏和GIF图多次触发onload的问题
                }
                // 容错处理 todo 应该如何处理呢?
                // 目前是忽略这个错误，不影响正常使用
            IMG.onerror = function() {
                window._pandaImageLoadArray.shift();
                IMG.onerror = null;
            }
            return _loadImages(pics, callback, len);
        }
        return;
    }
    if (callback) _loadProgress(callback, window._pandaImageLoadArray.length, len);
}
// 监听实际的加载情况
function _loadProgress(callback, begin, all) {
    var loadinterval = setInterval(function() {
        if (window._pandaImageLoadArray.length != 0 && window._pandaImageLoadArray.length != begin) {
            _drawLoadProgress((begin - window._pandaImageLoadArray.length) / all);
        } else if (window._pandaImageLoadArray.length == 0) {
            _drawLoadProgress(1)
            setTimeout(function() {
                callback.call(window);
            }, 500);
            clearInterval(loadinterval);
        }
    }, 300);
}

function _drawLoadProgress(w) {
    var num = Math.floor(w * 100) >= 100 ? 100 : Math.floor(w * 100) + 1;
    $(".ld_long").css("width",num+'%');
}


var id = getQueryString('id');
_loadImages(pics, function() {
    if(id){
        http.get('/empcare/essTbTeamOpen/getHmacSHA256ByCardId.do?cardId='+id,function(shaResponse){
            //正常数据
            initInform(listResponse)
        },function(error){
            setTimeout(function(){
                $(".ld_heart").show();
                $('.loading').fadeOut(1000);
                $("#CardPage").fadeIn(1200);
                setTimeout(() => {
                    initStars();
                }, 1000);
                $('.page1').addClass('play');
            },4000)
        })
    }else{
        var shaResponse = {
            appId:getQueryString('appId'),
            cardId:getQueryString('cardId'),
            timestamp:getQueryString('timestamp'),
            sign:getQueryString('sign')
        }
        initInform(shaResponse)
    }
    
})

//冒心心
// ld_heart();
function ld_heart(){
    var heartStage = new createjs.Stage("ldheart");
    heartStage.canvas.width = 250;
    heartStage.canvas.height = 150;
    var pic = new createjs.Bitmap(hkConfig.cdn+"ld_heart.png");
    var react = new createjs.Rectangle(0,0,30,30);
    pic.sourceRect = react;
    pic.x = heartStage.canvas.width / 2 - react.width / 2;
    pic.y = heartStage.canvas.height - react.height;
    heartStage.addChild(pic);
    console.log(pic);
    var randY = 40 ;
    createjs.Tween.get(pic, {loop: true}).to({y:randY/4,x:0,alpha:0.5}, 800, createjs.Ease.linear).to({y:randY*2,x:-randY,alpha:0}, 1000, createjs.Ease.linear);
    // for(var i = 0;i<96;i++){
        

    //     ss[i] = new createjs.Bitmap("./images/ld_heart.png");
    //     arr[i] = new createjs.Rectangle(frames[i],0,7,290);
    //     ss[i].x = frames[i];
    //     ss[i].sourceRect = arr[i];
    //     stage.addChild(ss[i]);

    //     wait[i] = i * 20

    //     createjs.Tween.get(ss[i], {loop: true}).wait(wait[i])
    //     .to({y:50}, 800, createjs.Ease.linear)
    //     .to({y:0}, 800, createjs.Ease.linear)
        
    // }

    createjs.Ticker.setFPS(60);
    //设置Fps，一般设置为60，大概每16毫秒刷新一次
    createjs.Ticker.addEventListener("tick", heartStage);
}
// 辅助处理初始化函数
function handleInitInform(response,linkURL,shaResponse){
  if(!response.imgOuterUrl){
      response.imgOuterUrl = hkConfig.cdn+'default.png'
  }
  if(localStorage.getItem('hkjump')){
      $(".jump").fadeIn();
  }else{
      localStorage.setItem('hkjump',true);
  }
  wxShare();
  $(".ld_avatar img,.end_avatar4 img").attr("src",response.imgOuterUrl)
  $(".UserName").html(response.name);
  $('#BirthdayNumber').html(response.paNumber)
  $('#Constellation').html(response.constellation);
  window['RegisterDays'] = response.entryDays;
  window['PartnerBirthday'] = response.paBirthday;
  window['userInform'] = response;
  window['shareInform'] = shaResponse;
  $.each(response.avatarList,function(i,item){
      if(item.imgOuterUrl != ''){
          $(".ea_item img").eq(i).attr("src",item.imgOuterUrl);
      }else{
          $(".ea_item img").eq(i).attr("src",'../images/default.png');
      }
  })
  // "cardType":"贺卡类型",
  //--01:直接上级单独贺卡/团队贺卡 测试id:6729 ,
  //--02:间接上级单独贺卡 测试id:10860 ,
  //--03:系统贺卡 测试id:6710
  if(response.cardType == '01'){
      //loading
      setTimeout(function(){
          $(".ld_heart").show();
          $('.loading').fadeOut(1000);
          $("#CardPage").fadeIn(1200);
          setTimeout(() => {
              initStars();
          }, 1000);
          $('.page1').addClass('play');
      },4000)
      // share(response.name,null,0,null,linkURL);

  }else if(response.cardType == '02'){
      setTimeout(function(){
          $(".ld_heart").show();
          $('.loading').fadeOut(1200,function(){
              initBirthday = 2;
              GM.init('Birthday');
              GM.goToScene('BIRTHDAY');
          });
      },4000)
      
      // share(response.name,response.leaderUmid,1,null,linkURL);
  }else{
      setTimeout(function(){
          $(".ld_heart").show();
          $('.loading').fadeOut(1200,function(){
              $('.system_page').show();
          });
      },4000)
      // share(response.name,null,2,null,linkURL);
  }
}
const isTest = false; //测试环境
//初始化数据
function initInform(shaResponse,linkURL){
  if(isTest){
    var api1Data = {
      "associatedId": "3758EE0C5FD24B0984D4543EC38408DE",
      "avatarList": [],
      "birthday": "1993-11-16 00:00:00",
      "birthdayYear": "2018",
      "cardType": "01",
      "constellation": "天蝎座",
      "constellationPost": "",
      "createBy": "ZZTJ",
      "createDate": "2018-11-16 08:05:56",
      "employeeId": "00010961355",
      "entryDays": "576",
      "explain": "",
      "id": 13842,
      "imgInnerUrl": "",
      "imgOuterUrl": "",
      "invitedId": 4927,
      "isRead": "Y",
      "isSend": "Y",
      "leaderEmployeeId": "",
      "leaderUmid": "",
      "name": "姜宏",
      "paBirthday": "920",
      "paNumber": "2",
      "state": "A",
      "umid": "JIANGHONG720",
      "updateBy": "ZZTJ",
      "updateDate": "2018-11-16 16:29:08"
    }
    handleInitInform(api1Data,linkURL,shaResponse);
    var api2Data = [
      {
              "associatedId": "3758EE0C5FD24B0984D4543EC38408DE",
              "audioDuration": "0",
              "birthday": "1993-11-16 00:00:00",
              "blessingEmpId": "00010042198",
              "blessingHead": "http://stg.iobs02.pingan.com.cn/download/zztj-hrx-dmz-stg/3477a5dc-922f-44fa-b9d0-77f39cbcf179",
              "blessingImgDmz": "",
              "blessingImgSf": "undefined",
              "blessingName": "佟柳",
              "blessingText": "姜宏，生日快乐，你很棒，继续加油！",
              "blessingUmid": "TONGLIU001",
              "blessingVoiceDmz": "",
              "blessingVoiceSf": "",
              "createBy": "TONGLIU001",
              "createDate": "2018-11-15 19:29:28",
              "employeeId": "00010961355",
              "id": 1290,
              "invitedHead": "",
              "invitedId": 4902,
              "invitedName": "郑秋菊",
              "invitedRecords": null,
              "invitedUmid": "ZHENGQIUJU548",
              "longevityId": null,
              "name": "姜宏",
              "state": "A",
              "umid": "JIANGHONG720",
              "updateBy": "TONGLIU001",
              "updateDate": "2018-11-16 08:05:56"
          },
          {
              "associatedId": "3758EE0C5FD24B0984D4543EC38408DE",
              "audioDuration": "0",
              "birthday": "1993-11-16 00:00:00",
              "blessingEmpId": "00010042203",
              "blessingHead": "http://stg.iobs02.pingan.com.cn/download/zztj-hrx-dmz-stg/6dc60b32-fee3-4722-a166-c0106a60e46a",
              "blessingImgDmz": "",
              "blessingImgSf": "undefined",
              "blessingName": "葛亮",
              "blessingText": "亲爱的，祝你生日快乐。很开心能和你共事成为朋友，开心每一天哦！",
              "blessingUmid": "GELIANG002",
              "blessingVoiceDmz": "",
              "blessingVoiceSf": "",
              "createBy": "GELIANG002",
              "createDate": "2018-11-15 19:31:35",
              "employeeId": "00010961355",
              "id": 1291,
              "invitedHead": "",
              "invitedId": 4903,
              "invitedName": "郑秋菊",
              "invitedRecords": null,
              "invitedUmid": "ZHENGQIUJU548",
              "longevityId": null,
              "name": "姜宏",
              "state": "A",
              "umid": "JIANGHONG720",
              "updateBy": "GELIANG002",
              "updateDate": "2018-11-16 08:05:56"
          },
          {
              "associatedId": "3758EE0C5FD24B0984D4543EC38408DE",
              "audioDuration": "21.05469387755102",
              "birthday": "1993-11-16 00:00:00",
              "blessingEmpId": "00010052996",
              "blessingHead": "http://stg.iobs02.pingan.com.cn/download/zztj-hrx-dmz-stg/eecc81ea-bd39-4948-a514-b8201bde0864",
              "blessingImgDmz": "",
              "blessingImgSf": "undefined",
              "blessingName": "林玲",
              "blessingText": "",
              "blessingUmid": "LINLING014",
              "blessingVoiceDmz": "https%3A%2F%2Fstg.iobs.pingan.com.cn%2Fdownload%2Fzztj-hrx-dmz-stg%2F55ffe3296717256e01671728ec5e0001",
              "blessingVoiceSf": "http%3A%2F%2Fstg.iobs.paic.com.cn%2Fdownload%2Fzztj-hrx-dmz-stg%2F55ffe3296717256e01671728ec5e0001",
              "createBy": "LINLING014",
              "createDate": "2018-11-15 19:36:57",
              "employeeId": "00010961355",
              "id": 1294,
              "invitedHead": "",
              "invitedId": 4906,
              "invitedName": "郑秋菊",
              "invitedRecords": null,
              "invitedUmid": "ZHENGQIUJU548",
              "longevityId": null,
              "name": "姜宏",
              "state": "A",
              "umid": "JIANGHONG720",
              "updateBy": "LINLING014",
              "updateDate": "2018-11-16 08:05:56"
          }
    ]
    initSwiper(api2Data || []);
    return false
  }
  http.get('/empcare/essTbTeamOpen/queryCardInformById.do?appId='+shaResponse.appId+'&cardId='+shaResponse.cardId+'&sign='+shaResponse.sign+'&timestamp='+shaResponse.timestamp,function(response){

      var linkURL = hkConfig.api+'/hrx-ess/birthdaycard/?appId='+shaResponse.appId+"&cardId="+shaResponse.cardId+"&sign="+shaResponse.sign+"&timestamp="+shaResponse.timestamp
      initInform(response,linkURL,shaResponse)
  },function(error){
      window['RegisterDays'] = 1234;
      window['PartnerBirthday'] = 1234;

  })
  http.get('/empcare/essTbTeamOpen/querySuperiorGreetCard.do?appId='+shaResponse.appId+'&cardId='+shaResponse.cardId+'&sign='+shaResponse.sign+'&timestamp='+shaResponse.timestamp,function(SuperiorResponse){
      //正常数据
      // initSwiper(listResponse.data);
      initSwiper(SuperiorResponse || []);
  },function(error){
      initSwiper(listResponse.data);
  })
}





var msgSlide = {
    preStatus:true,
    nextStatus:true,
    endnum:0,
    preEnd:function(){
        if(!msgSlide.preStatus){return false;}
        msgSlide.preStatus = false;
        $(".self_pagination_pre").css({
            "left":"6.4rem",
            "top":"-0.5rem",
            'transform':'scale(1)',
            'boxShadow': "0 0 10px 2px rgba(254,121,58,0.6)"
        });

        $(".self_pagination_active").css({
            "left":"10.1rem",
            "top":"0.1rem",
            "opacity":'1',
            "transform":"scale(0.35)",
            'boxShadow': "0 0 2px 0px rgba(254,121,58,0.8)"
        });

        $(".self_pagination_next").css({
            "left":"12.9rem",
            "top":"1.37rem",
            "opacity":'0',
            'boxShadow': "0 0 2px 0px rgba(254,121,58,0.8)"
        });


        $(".self_pagination .self_before_dom").css({
            "left":"2.9rem",
            "top":"0rem",
            "opacity":'1',
            'boxShadow': "0 0 2px 0px rgba(254,121,58,0.8)"
        });


        setTimeout(function(){
            $(".self_pagination_active").addClass('self_pagination_next').removeClass('self_pagination_active');
            $(".self_pagination .self_pagination_next:last").remove();
            $(".self_pagination_pre").addClass('self_pagination_active').removeClass('self_pagination_pre');
            $(".self_pagination .self_before_dom").addClass('self_pagination_pre').removeClass("self_before_dom");

            $(".self_pagination").prepend('<span class="self_pagination_item self_before_dom"></span>');
            msgSlide.preStatus = true;
        },400)
    },
    nextEnd:function(e){
        if(!msgSlide.nextStatus){return false;}
        msgSlide.nextStatus = false;
        $(".self_pagination_pre").css({
            "left":"0.5rem",
            "top":"1rem",
            "opacity":'0',
            'boxShadow': "0 0 2px 0px rgba(254,121,58,0.8)"
        });

        $(".self_pagination_active").css({
            "left":"2.9rem",
            "top":"0rem",
            'transform':'scale(0.35)',
            'boxShadow': "0 0 2px 0px rgba(254,121,58,0.8)"
        });

        $(".self_pagination_next").css({
            "left":"6.4rem",
            "top":"-0.5rem",
            'transform':'scale(1)',
            'boxShadow': "0 0 10px 2px rgba(254,121,58,0.6)"
        });
        $(".self_pagination .self_after_dom").css({
            "left":"10.1rem",
            "top":"0.1rem",
            "opacity":'1',
            'boxShadow':"0 0 2px 0px rgba(254,121,58,0.8)"
        });
        $(".hand_right_tip").fadeOut();
        // console.log(e.activeIndex);
        // console.log(e.slides.length);
        setTimeout(function(){
            $(".self_pagination_active").addClass('self_pagination_pre').removeClass('self_pagination_active');
            $(".self_pagination .self_pagination_pre").eq(0).remove();
            $(".self_pagination_next").addClass('self_pagination_active').removeClass('self_pagination_next');
            $(".self_pagination .self_after_dom").addClass('self_pagination_next').removeClass("self_after_dom");
            $(".self_pagination").append('<span class="self_pagination_item self_after_dom"></span>');
            if(e.activeIndex < e.slides.length - 2){
                
            }
            msgSlide.nextStatus = true;
        },400)
    }
}


var listResponse = {
    "responseCode": "10001",
    "responseMsg": "请求成功",
    "data":[
        {
            "invitedId":"123456",    
            "birthday":"1990-10-18",      
            "blessingUmid":"123456",       
            "blessingName":"范冰冰1",       
            "blessingHead":"http://www.qqtouxiang.com/d/file/tupian/mx/20170811/jisi0du5z1itj.jpg",       
            "umid":"123456",
            "employeeId":"123456",
            "name":"李晨1",
            "invitedName":"范冰冰1",
            "invitedUmid":"123456",
            "invitedHead":"邀请人头像",
            "blessingImgSf":"祝福图片-内网url",
            "blessingImgDmz":"https://stg.iobs.pingan.com.cn/download/zztj-hrx-dmz-stg/9d8b972a66f1d6660166f20f01ea0003",
            "blessingText":"测试祝福测试祝福测试祝福测试祝福",
            "blessingVoiceSf":"语音祝福-内网",
            "blessingVoiceDmz":"https://stg.iobs.pingan.com.cn/download/zztj-hrx-dmz-stg/55ffe32a67163159016716893e300006",
            "state":"1",
            "blessingEmpId":"祝福人员工号"
        },
        {
            "invitedId":"123456",    
            "birthday":"1990-10-18",      
            "blessingUmid":"123456",       
            "blessingName":"范冰冰1",       
            "blessingHead":"http://www.qqtouxiang.com/d/file/tupian/mx/20170811/jisi0du5z1itj.jpg",       
            "umid":"123456",
            "employeeId":"123456",
            "name":"李晨1",
            "invitedName":"范冰冰1",
            "invitedUmid":"123456",
            "invitedHead":"邀请人头像",
            "blessingImgSf":"祝福图片-内网url",
            "blessingImgDmz":"https://stg.iobs.pingan.com.cn/download/zztj-hrx-dmz-stg/9d8b972a66f1d6660166f20f01ea0003",
            "blessingText":"测试祝福测试祝福测试祝福测试祝福",
            "blessingVoiceSf":"语音祝福-内网",
            "blessingVoiceDmz":"https://stg.iobs.pingan.com.cn/download/zztj-hrx-dmz-stg/55ffe32a67163159016716893e300006",
            "state":"1",
            "blessingEmpId":"祝福人员工号"
        },
        {
            "invitedId":"123456",    
            "birthday":"1990-10-18",      
            "blessingUmid":"123456",       
            "blessingName":"范冰冰1",       
            "blessingHead":"http://www.qqtouxiang.com/d/file/tupian/mx/20170811/jisi0du5z1itj.jpg",       
            "umid":"123456",
            "employeeId":"123456",
            "name":"李晨1",
            "invitedName":"范冰冰1",
            "invitedUmid":"123456",
            "invitedHead":"邀请人头像",
            "blessingImgSf":"祝福图片-内网url",
            "blessingImgDmz":"https://stg.iobs.pingan.com.cn/download/zztj-hrx-dmz-stg/9d8b972a66f1d6660166f20f01ea0003",
            "blessingText":"测试祝福测试祝福测试祝福测试祝福",
            "blessingVoiceSf":"语音祝福-内网",
            "blessingVoiceDmz":"https://stg.iobs.pingan.com.cn/download/zztj-hrx-dmz-stg/55ffe32a67163159016716893e300006",
            "state":"1",
            "blessingEmpId":"祝福人员工号"
        }
    ]
}


// initSwiper(listResponse.data);

function initSwiper(data){
    var isEnd = false;
    var swiper = new Swiper('.swiper-container', {
        slidesPerView: 1,
        centeredSlides: true,
        spaceBetween: 30,
        loop:false,
        pagination: {
            el: '.swiper-pagination',
            // dynamicBullets: true,
            dynamicMainBullets: 1
        },
        on:{
            init:function(){
                $(".msg_page").addClass('play_ballon');
                if(data.length <= 1){
                    $(".hand_right_tip").hide();
                }
            },
            slideChange:function(mySwiper){
    
            },
            slidePrevTransitionEnd(){
                stopAudio();
                msgSlide.preEnd();
                var $currentObj = $(swiper.slides[this.activeIndex]);
                if($currentObj.hasClass('colleagues_card')){
                    $(".msg_page").removeClass('play_ballon');
                }else{
                    $(".bg_balloon_top").css({
                        'transform':'translate(0rem,0rem) scale(0.8)',
                    });
                    $(".bg_cake_top").css({
                        'transform':'translate(0rem,0rem) scale(1)',
                    });
                    $(".bg_balloon_bottom").css({
                        'transform':'translate(0rem,0rem)',
                    });
                    $(".employees_bg").fadeOut(1000);
    
                    $(".msg_page").addClass('play_ballon');
    
                    $(".bg_bubble").css({
                        'transform':'translate(0rem,-4rem)',
                    });
                    $(".bg_crane").css({
                        'transform':'translate(0rem,0rem)',
                    });
                    $(".pink_balloon").css({
                        'transform':'translate(0rem,0rem)',
                    });
                    // $(".msg_page").removeClass('play_bubble');
                }
            },
            slideNextTransitionEnd(){
                stopAudio();
                msgSlide.nextEnd(this);
                var $currentObj = $(swiper.slides[this.activeIndex]);
                if($currentObj.hasClass('colleagues_card')){
                    $(".bg_balloon_top").css({
                        'transform':'translate(9.5rem, 12rem) scale(1)',
                    });
                    $(".bg_cake_top").css({
                        'transform':'translate(-10rem,-3rem)',
                    });
                    
                    $(".bg_balloon_bottom").css({
                        'transform':'translate(0rem,12rem)',
                    });
                    $(".pink_balloon").css({
                        'transform':'translate(-3rem,3rem)',
                    });
                    
                    $(".employees_bg").fadeIn(1000);
                    $(".msg_page").removeClass('play_ballon');
    
                    $(".bg_crane").css({
                        'transform':'translate(0rem,6rem)',
                    });
    
                    // 气泡
                    $(".bg_bubble").css({
                        'transform':'translate(2rem,2.5rem)',
                    });
                    $(".msg_page").addClass('play_bubble');
                }else{
                    $(".msg_page").addClass('play_ballon');
                }
            },
            setTranslate: function(translate){
                stopAudio()
                var TR = Math.abs(translate);
                if(TR > 40 && $(".msg_container .swiper-slide").length==1){
                    if(userInform.cardType == '02'){
                        $(".end_avatar_area,.end_desc").hide();
                    }
                    $(".msg_page").fadeOut(1500);
                    $(".end_page").fadeIn(1500);
                }


            },
            progress: function(progress){
                // console.log(progress);
                if($(".msg_container .swiper-slide").length > 1){
                    if(progress > 1.04){
                        if(userInform.cardType == '02'){
                            $(".end_avatar_area,.end_desc").hide();
                        }
                        $(".msg_page").fadeOut(1500);
                        $(".end_page").fadeIn(1500);
                    }
                }
                
            }
        },
        virtual: {
            slides: data,
            renderSlide:function(slide, index){
                slide.audioDuration = Number(slide.audioDuration).toFixed(1);
                slide.blessingVoiceDmz = decodeURIComponent(slide.blessingVoiceDmz);
                var voiceData = "<div class='msg_voice1'><div class='voice1_content'><audio class='voice_item' preload='auto'><source src='"+slide.blessingVoiceDmz+"' type='audio/mpeg'></audio><div class='voice1_left'><div class='voice_play'></div><div class='voice_pause'></div></div><div class='voice1_center'><div class='voice_progress'><div class='voice_long'></div></div></div><div class='voice1_right'><div class='voice_seconds'>"+slide.audioDuration+"'</div><div class='voice_unread'></div></div></div></div>"
                var textData = '<div class="msg_content"><p><span class="quotes_start"></span>'+slide.blessingText+'<span class="quotes_end"></span></p></div>';
                var cardContent = slide.blessingVoiceDmz == "" ? textData:voiceData;
                var className = index!='0'?'colleagues_card':'';
                var imgBox = slide.blessingImgDmz !='' ?'<div class="msg_pic_box"><img src='+decodeURIComponent(slide.blessingImgDmz+'/imageView/2/w/500/format/jpeg')+'></div>':'';
                slide.blessingHead = slide.blessingHead==''?hkConfig.cdn+"default.png":slide.blessingHead;
                var dom = '<div class="swiper-slide '+className+'"><div class="slides_inner"><div class="border_tb"></div><div class="border_lr"></div>'+
                    imgBox+
                    '<div class="msg_to_area"><p><span class="to_icon"></span>'+
                    '<span class="to_name">'+slide.name+'</span>'+
                    '</p></div>'+cardContent+'<div class="msg_from">'+
                    '<p><span class="from_name">from '+slide.blessingName+'.</span><span class="from_avatar"><img src="'+slide.blessingHead+'" alt=""></span></p>'+
                    '</div></div></div>'
                return dom;
            },
          },
    });
}

// 停止播放所有语音
function stopAudio(){
    $(".voice_item").each(function(){
        $(this)[0].pause();
        $(this).parents(".msg_voice1").find(".voice_play").show();
        $(this).parents(".msg_voice1").find(".voice_pause").hide()
    })
}

// 语音播放
$(".msg_container").on("click",'.swiper-slide .msg_voice1',function(){
    //播放
    if($(this).find(".voice_play").is(":visible")){
        $(this).find('audio')[0].play();
        $(this).find('.voice_play').hide();
        $(this).find('.voice_pause').show();
        music.volume = 0.5;
        var duration = parseInt($(this).find('.voice_seconds').attr('vsec'));
        var $audio = $(this).find('audio')[0];
        $(this).find('.voice_unread').css('opacity','0')
        _this = $(this);
        $(this).find('audio').on("timeupdate",function(){
            var progressValue = $audio.currentTime/$audio.duration*100;
            _this.find('.voice_long').css("width",progressValue+'%');
            console.log(progressValue);
            if(progressValue >= 100){
                _this.find('.voice_play').show();
                _this.find('.voice_pause').hide();
            }
        })
    //暂停
    }else{
        music.volume = 1;
        $(this).find('audio')[0].pause();
        $(this).find('.voice_play').show();
        $(this).find('.voice_pause').hide();
    }
    
})




var http = {};
http.post = function(url,data,successCallbck,errorCallback){
    if(App.isXRX){
        App.getSession(function(token){
            $.ajax({
                method: 'post',
                url: hkConfig.api + url,
                data: JSON.stringify(data),
                headers: {
                    "Content-Type":"application/json",
                    'X-HRX-SESSION':token
                },
                success:function(response){
                    if ( response.responseCode == '10001' ) {
                        successCallbck && successCallbck(response.data);
                    }
                },
                error:function(error){
                    errorCallback && errorCallback(error);
                }
            })
        })

    }else{
        $.ajax({
            method: 'post',
            url: hkConfig.api + url,
            data: JSON.stringify(data),
            headers: {
                "Content-Type":"application/json",
                'X-HRX-SESSION':hkConfig.accessToken
            },
            success:function(response){
                if ( response.responseCode == '10001' ) {
                    successCallbck && successCallbck(response.data);
                }
            },
            error:function(error){
                errorCallback && errorCallback(error);
            }
        })
    }
}


http.get = function(url,successCallbck,errorCallback){
    if(App.isXRX){
        App.getSession(function(token){
            $.ajax({
                method: 'get',
                url: hkConfig.api + url,
                headers: {
                    "Content-Type":"application/json",
                    'X-HRX-SESSION':token
                },
                success:function(response){
                    if ( response.responseCode == '10001' ) {
                        successCallbck && successCallbck(response.data);
                    }
                },
                error:function(error){
                    errorCallback && errorCallback(error);
                }
            })
        })

    }else{
        $.ajax({
            method: 'get',
            url: hkConfig.api + url,
            headers: {
                "Content-Type":"application/json",
                'X-HRX-SESSION':hkConfig.accessToken
            },
            success:function(response){
                if ( response.responseCode == '10001' ) {
                    successCallbck && successCallbck(response.data);
                }
            },
            error:function(error){
                errorCallback && errorCallback(error);
            }
        })
    }
}



// window['RegisterDays'] = 1050;
// window['PartnerBirthday'] = 404;




//白色随机点
// particlesJS('white_point',{
//     "particles": {
//         "number": {
//         "value": 60,
//         "density": {
//             "enable": true,
//             "value_area": 100
//         }
//         },
//         "color": {
//         "value": "#ffffff"
//         },
//         "shape": {
//         "type": "circle",
//         "polygon": {
//             "nb_sides": 5
//         },
//             "image": {
//                 "src": "img/github.svg",
//                 "width": 100,
//                 "height": 100
//             }
//         },
//         "opacity": {
//         "value": 0.5,
//         "random": true,
//         "anim": {
//             "enable": true,
//             "speed": 0.5,
//             "opacity_min": 0.1,
//             "sync": false
//         }
//         },
//         "size": {
//             "value":1.1,
//             "random": true,
//             "anim": {
//                 "enable": true,
//                 "speed": 0.5,
//                 "size_min": 0.1,
//                 "sync": false
//             }
//         },
//         "line_linked": {
//             "enable": false,
//             "distance": 300,
//             "color": "#ffffff",
//             "opacity": 0.4,
//             "width": 2
//         },
//         "move": {
//             "enable": true,
//             "speed": 0.6,
//             "direction": "none",
//             "random": true,
//             "straight": false,
//             "out_mode": "out",
//             "bounce": false
//         }
//     },
//     "interactivity": {
//         "detect_on": "canvas",
//         "events": {
//         "onhover": {
//             "enable": false,
//             "mode": "repulse"
//         },
//         "onclick": {
//             "enable": true,
//             "mode": "push"
//         },
//         "resize": true
//         }
//     },
//     "retina_detect": true
// });

function initStars(){
    particlesJS('white_shadow_point',{
        "particles": {
            "number": {
            "value": 20,
            "density": {
                "enable": true,
                "value_area": 80
            }
            },
            "color": {
            "value": "#ffffff"
            },
            "shape": {
            "type": "image",
            "polygon": {
                "nb_sides": 5
            },
                "image": {
                    "src": "../images/p2_shadow_point.png",
                    "width": 34,
                    "height": 34
                }
            },
            "opacity": {
            "value": 0.5,
            "random": true,
            "anim": {
                "enable": true,
                "speed": 0.5,
                "opacity_min": 0.1,
                "sync": false
            }
            },
            "size": {
                "value":8,
                "random": true,
                "anim": {
                    "enable": true,
                    "speed": 0.5,
                    "size_min": 5,
                    "sync": false
                }
            },
            "line_linked": {
                "enable": false,
                "distance": 300,
                "color": "#ffffff",
                "opacity": 0.4,
                "width": 2
            },
            "move": {
                "enable": true,
                "speed": 0.8,
                "direction": "none",
                "random": true,
                "straight": false,
                "out_mode": "out",
                "bounce": false
            }
        },
        "interactivity": {
            "detect_on": "canvas",
            "events": {
            "onhover": {
                "enable": false,
                "mode": "repulse"
            },
            "onclick": {
                "enable": true,
                "mode": "push"
            },
            "resize": true
            }
        },
        "retina_detect": true
    });
    
    // 黄色发光随机点
    particlesJS('white_yello_point',{
        "particles": {
            "number": {
            "value": 20,
            "density": {
                "enable": false,
                "value_area": 80
            }
            },
            "color": {
            "value": "#ffffff"
            },
            "shape": {
                "type": "image",
                "polygon": {
                    "nb_sides": 5
                },
                "image": {
                    "src": "../images/p2_yello_point.png",
                    "width": 46,
                    "height": 46
                }
            },
            "opacity": {
                "value": 10,
                "random": true,
                "anim": {
                    "enable": true,
                    "speed": 50,
                    "opacity_min": 0.1,
                    "sync": false
                }
            },
            "size": {
                "value":10,
                "random": true,
                "anim": {
                    "enable": true,
                    "speed": 0.5,
                    "size_min": 5,
                    "sync": false
                }
            },
            "line_linked": {
                "enable": false,
                "distance": 300,
                "color": "#ffffff",
                "opacity": 0.4,
                "width": 2
            },
            "move": {
                "enable": true,
                "speed": 0.5,
                "direction": "none",
                "random": true,
                "straight": false,
                "out_mode": "out",
                "bounce": false,
            }
        },
        "interactivity": {
            "detect_on": "canvas",
            "events": {
            "onhover": {
                "enable": false,
                "mode": "repulse"
            },
            "onclick": {
                "enable": true,
                "mode": "push"
            },
            "resize": true
            }
        },
        "retina_detect": true
    });
}


// 微信分享
function wxShare(){
  if(!link){ var link = location.href; }
  var uri = encodeURIComponent(window.location.href.split("#")[0]);
// console.log(window.location.href.split("#")[0])
  $.ajax({
    type:"GET",
    url:hkConfig.wxApi+"/cram/wechat/sign.do?url="+uri,
    dataType: "jsonp",
    headers:{
        "Access-Control-Allow-Origin":"*"
    },
    jsonp: "jsonpCallback"
  })
}
function jsonpCallback(res){
    var uri = window.location.href.split("#")[0];
    if(userInform.cardType == '01'){
        var ind = 0;
    }else if(userInform.cardType == '02'){
        var ind = 1;
    }else{
        var ind = 2;
    }
    var shareContent = [
        //管理者（邀请）贺卡
        {
            title:'亲爱的'+name+'，祝您生日快乐！',
            desc:"团队小伙伴一起为您准备的生日惊喜，请点击查看"
        },
        //管理者（未邀请）、间接上级贺卡
        {
            title:'亲爱的'+name+'，祝您生日快乐！',
            desc:userInform.leaderUmid+"为您送上了一张生日贺卡，请点击查看"
        },
        //系统贺卡
        {
            title:'亲爱的'+name+'，祝您生日快乐！',
            desc:"希望您生活幸福美满，每天都拥有好心情"
        }
    ]

    var data = res.data;

    var apilist = [
        'onMenuShareTimeline',
        'onMenuShareAppMessage'
    ];
    
    wx.config({
        debug: false,
        appId: data.appId,
        timestamp: data.timestamp,
        nonceStr: data.nonceStr,
        signature: data.signature,
        jsApiList: apilist
    });

    wx.ready(function () {
        // 分享给朋友事件绑定
        wx.onMenuShareAppMessage({
            title: shareContent[ind].title,
            desc: shareContent[ind].desc,
            link: uri,
            imgUrl: 'https://iobs02.pingan.com.cn/download/zztj-hrx-dmz-prd/9d8fa0c166b5240c0166f75bd9260028',
            success: function () {

            }
        });

        // 分享到朋友圈
        wx.onMenuShareTimeline({
            title:shareContent[ind].title,
            link: uri,
            imgUrl: 'https://iobs02.pingan.com.cn/download/zztj-hrx-dmz-prd/9d8fa0c166b5240c0166f75bd9260028',
            success: function () {

            }
        });
    })
}
if(hkConfig.debugger){
    var vConsole = new VConsole();
}


if(App.isXRX){
    
    http.post('/empcare/essTbBirthdayCard/updateBirthdayCardReadById.do',{
        id:id
    })
    App.hideLoading();
    App.changeHeader({
        left: {
          type: 'icon',
          icon: 'nav_back_forh5',
          callback: function() {
            music.pause();
            if(window.back) {
              window.back();
            } else {
              App.refreshHrxHome();
              App.popH5Window();
            }
          }
        },
        title: '平安生日贺卡',
        right: {
            type: 'text',
            text: '分享',
            callback: function() {
                $(".share").fadeIn(500,function(){
                    $(".share_area").css({
                        "transform":"translate(0,0)"
                    })
                });
            }
        }
    });
}else{
    
    $(".end_tool_share").hide();
}

$(".end_tool_share").on("click",function(){
    $(".share").fadeIn(500,function(){
        $(".share_area").css({
            "transform":"translate(0,0)"
        })
    });
})

$(".share").on("click",function(){
    $(".share_area").css({
        "transform":"translate(0,10.6rem)"
    })
    $(".share").fadeOut();
})

$(".share_area").on("click",function(event){
    event.stopPropagation();
})

//重播
$(".end_tool_replay").on("click",function(){
    window.location.reload();
})

function share(name,leader,index,WXScene,link){
    var shareContent = [
        //管理者（邀请）贺卡
        {
            title:'亲爱的'+name+'，祝您生日快乐！',
            desc:"团队小伙伴一起为您准备的生日惊喜，请点击查看"
        },
        //管理者（未邀请）、间接上级贺卡
        {
            title:'亲爱的'+name+'，祝您生日快乐！',
            desc:leader+"为您送上了一张生日贺卡，请点击查看"
        },
        //系统贺卡
        {
            title:'亲爱的'+name+'，祝您生日快乐！',
            desc:"希望您生活幸福美满，每天都拥有好心情"
        }
    ]
    if(App.isXRX){
        var thumbUrl = "https://iobs02.pingan.com.cn/download/zztj-hrx-dmz-prd/9d8fa0c166b5240c0166f75bd9260028";
        App.shareGlobel(0, link, shareContent[index].title, shareContent[index].desc, thumbUrl, '', WXScene,function(){
            $(".share_area").css({
                "transform":"translate(0,10.6rem)"
            })
            $(".share").fadeOut();
        })
    }
}

$(".share_moments").on("click",function(){
    var linkURL = hkConfig.api+'/hrx-ess/birthdaycard/?appId='+shareInform.appId+"&cardId="+shareInform.cardId+"&sign="+shareInform.sign+"&timestamp="+shareInform.timestamp
    if(userInform.cardType == '01'){
        var ind = 0;
    }else if(userInform.cardType == '02'){
        var ind = 1;
    }else{
        var ind = 2;
    }
    share(userInform.name,userInform.leaderUmid,ind,1,linkURL);
})

$(".share_friends").on("click",function(){
    var linkURL = hkConfig.api+'/hrx-ess/birthdaycard/?appId='+shareInform.appId+"&cardId="+shareInform.cardId+"&sign="+shareInform.sign+"&timestamp="+shareInform.timestamp
    if(userInform.cardType == '01'){
        var ind = 0;
    }else if(userInform.cardType == '02'){
        var ind = 1;
    }else{
        var ind = 2;
    }
    share(userInform.name,userInform.leaderUmid,ind,0,linkURL);
})

